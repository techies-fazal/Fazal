@extends('layouts.app')

@section('title', trans('company.list'))

@section('content')
<h1 class="page-header">
    <div class="pull-left">
    @can('create', new App\Company)
        {{ link_to_route('companies.create', trans('company.create'), [], ['class' => 'btn btn-success']) }}
    @endcan
    </div><br>
    <!-- {{ trans('company.list') }}
    <small>{{ trans('app.total') }} : {{ $companies->total() }} {{ trans('company.company') }}</small> -->
</h1>
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default table-responsive pad-40">
            <div class="col-md-2">
                <div class="panel-heading pull-left">
                    <b>{{ trans('company.list') }}</b>
                </div>
            </div>
              <div class="col-md-10">
                <div class="panel-heading pull-right">
                {{ Form::open(['method' => 'get','class' => 'form-inline']) }}
                {!! FormField::text('q', ['value' => request('q'), 'label' => trans(''), 'class' => 'input-sm']) !!}
                {{ Form::submit(trans('company.search'), ['class' => 'btn btn-sm']) }}
                {{ link_to_route('companies.index', trans('app.reset')) }}
                {{ Form::close() }}
            </div>
             </div>
            <table class="table table-condensed">
                <thead>
                    <tr>
                        <th width="5%" class="text-center">{{ trans('app.table_no') }}</th>
                        <th width="20%">{{ trans('company.name') }}</th>
                        <th width="15%">{{ trans('company.email') }}</th>
                        <th width="15%">{{ trans('company.website') }}</th>
                        <th width="25%">{{ trans('company.address') }}</th>
                        <th width="15%" class="text-center">{{ trans('app.action') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($companies as $key => $company)
                    <tr>
                        <td class="text-center">{{ $companies->firstItem() + $key }}</td>
                        <td>{{ $company->name }}</td>
                        <td>{{ $company->email }}</td>
                        <td>{{ $company->website }}</td>
                        <td>{{ $company->address }}</td>
                        <td class="text-center">
                        @can('view', $company)
                            {!! link_to_route(
                                'companies.edit',
                                trans('app.edit'),
                                [$company],
                                ['class' => 'btn btn-default btn-s', 'style' => 'color:#636b6f', 'id' => 'show-company-' . $company->id]
                            ) !!}
                        @endcan
                         
                        @can('delete', $company)
                            {{ link_to_route('companies.edit', trans('app.delete'), [$company, 'action' => 'delete'], ['class' => 'btn btn-danger pull-right', 'id' => 'del-company-'.$company->id]) }}
                        @endcan
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            <div class="panel-body">{{ $companies->appends(Request::except('page'))->render() }}</div>
        </div>
    </div>
</div>
@endsection

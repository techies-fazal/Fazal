@extends('layouts.master')

@section('content')

<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">A{{__('dd Users')}}</h1>
        <a href="{{route('users.index')}}" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-arrow-left fa-sm text-white-50"></i> {{__('Back')}}</a>
    </div>

    {{-- Alert Messages --}}
    @include('common.alert')
   
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">{{__('Add New User')}}</h6>
        </div>
        <div class="card-body">
            <form method="POST" action="{{route('users.store')}}">
                @csrf
                <div class="form-group row">
 
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <div class="form-group">
                            {{ Form::label('name', __('Name'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                            <input type="text" class="form-control form-control-user @error('name') is-invalid @enderror" 
                                placeholder="Enter Name" name="name" value="{{ old('name') }}">
                            @error('name')
                                <span class="text-danger">{{$message}}</span>
                            @enderror
                        </div>
                    </div>

                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <div class="form-group">
                            {{ Form::label('contact_no', __('Contact No'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                            <input type="text" class="form-control form-control-user @error('contact_no') is-invalid @enderror" 
                                placeholder="Enter Contact No" name="contact_no" value="{{ old('contact_no') }}" onkeypress = "return isNumberKey(event)">
                            @error('contact_no')
                                <span class="text-danger">{{$message}}</span>
                            @enderror
                        </div>
                    </div>
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <div class="form-group">
                            {{ Form::label('address', __('Address'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                            <textarea name="address" id="address" cols="10" rows="3" placeholder="Enter Address" class="form-control form-control-user @error('contact_no') is-invalid @enderror" value="{{ old('name') }}"></textarea>
                            @error('address')
                                <span class="text-danger">{{$message}}</span>
                            @enderror
                        </div>
                    </div>
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <div class="form-group">
                            {{ Form::label('place', __('Place'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                            <input type="text" class="form-control form-control-user @error('place') is-invalid @enderror" 
                                placeholder="Enter place" name="place" value="{{ old('place') }}">
                            @error('place')
                                <span class="text-danger">{{$message}}</span>
                            @enderror
                        </div>
                    </div>
                    <!-- <div class="col-sm-6 mb-3 mb-sm-0">
                        <div class="form-group">
                            {{ Form::label('status', __('User Status'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                            <select id="status" name="status" class="form-control form-control-user">
                                <option value="" selected>{{__('Select User Status')}}</option>
                                <option value="0">{{__('Active')}}</option>
                                <option value="1">{{__('Inactive')}}</option>
                            </select>
                            @error('status')
                                <span class="text-danger">{{$message}}</span>
                            @enderror
                        </div>
                    </div> -->
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <div class="form-group">
                            {{ Form::label('email', __('Email'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                            <input type="text" class="form-control form-control-user @error('email') is-invalid @enderror" 
                                placeholder="Enter Email" name="email" value="{{ old('email') }}" >
                            @error('email')
                                <span class="text-danger">{{$message}}</span>
                            @enderror
                        </div>
                    </div>

                   
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <div class="form-group">
                            {{ Form::label('password', __('Password'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                            <input type="text" class="form-control form-control-user @error('password') is-invalid @enderror" 
                                placeholder="Enter Password" name="password" value="{{ old('password')}}">
                            @error('password')
                                <span class="text-danger">{{$message}}</span>
                            @enderror
                        </div>
                    </div>

                     <div class="col-sm-6 mb-3 mb-sm-0">
                        <div class="form-group">
                            {{ Form::label('role', __('Role'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                            <select id="role" name="role" class="form-control form-control-user @error('role') is-invalid @enderror" >
                                <option value="" selected>{{__('Select User Role')}}</option>
                                <option value="1">{{__('Vendor')}}</option>
                                <option value="2">{{__('Customer')}}</option>
                            </select>
                            @error('role')
                                <span class="text-danger">{{$message}}</span>
                            @enderror
                        </div>
                    </div>

                </div>

                {{-- Save Button --}}
                <button type="submit" class="btn btn-success btn-user btn-block">{{__('Save')}}</button>

            </form>
        </div>
    </div>

</div>


@endsection
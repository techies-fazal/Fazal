@extends('layouts.master')

@section('content')

<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">{{__('product Management')}}</h1>
        <a href="{{route('product.index')}}" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-arrow-left fa-sm text-white-50"></i>{{__('Back')}}</a>
    </div>

    {{-- Alert Messages --}}
    @include('common.alert')
   
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">{{__('Donor Details')}}</h6>
        </div>
        <div class="card-body">
                <div class="form-group row">

                    {{-- Donor name --}}
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        {{ Form::label('donor_name', __('Donor Name'), ['class' => 'col-form-label']) }}
                        <input readonly class="form-control form-control-user" value="{{$products->donor_name }}">
                    </div>

                    {{-- product Group --}}
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        {{ Form::label('donation_date', __('product Group'), ['class' => 'col-form-label']) }}
                        <select id="product_group" name="product_group" class="form-control form-control-user" readonly>
                            <option value="A+" @if($products->product_group == 'A+') selected @endif >{{__('A+')}}</option>
                            <option value="A-" @if($products->product_group == 'A-') selected @endif >{{__('A-')}}</option>
                            <option value="B+" @if($products->product_group == 'B+') selected @endif >{{__('B+')}}</option>
                            <option value="B-" @if($products->product_group == 'B-') selected @endif >{{__('B-')}}</option>
                            <option value="AB+"@if($products->product_group == 'AB+') selected @endif >{{__('AB+')}}</option>
                        </select>
                        
                    </div>

                    {{-- Date of Donation --}}
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        {{ Form::label('donation_date', __('Date of Donation'), ['class' => 'col-form-label']) }}
                        <input readonly class="form-control form-control-user" value="{{ $products->donation_date }}">
                    </div>

                    {{-- Quantity (in ml) --}}
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        {{ Form::label('product_quandity', __('Quantity (in ml)'), ['class' => 'col-form-label']) }}
                        <input readonly class="form-control form-control-user" value="{{ $products->product_quandity }}">
                    </div>
                </div>
 
        </div>
    </div>

</div>


@endsection
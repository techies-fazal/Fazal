@extends('layouts.master')

@section('content')

<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">{{__('Edit Product Management')}}</h1>
        <a href="{{route('product.index')}}" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-arrow-left fa-sm text-white-50"></i> {{__('Back')}}</a>
    </div>

    {{-- Alert Messages --}}
    @include('common.alert')
   
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">{{__('Edit Product')}}</h6>
        </div>
        <div class="card-body">
            <form method="POST" action="{{route('product.update', ['product' => $products->id])}}">
                @csrf
                @method('PUT')
                <div class="form-group row">

                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        {{ Form::label('product_name', __('Product Name'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                        <input type="text" class="form-control form-control-user @error('product_name') is-invalid @enderror" id="product_name"
                            placeholder="Enter product Name" name="product_name" value="{{ old('product_name') ? old('product_name') : $products->product_name }}">
                        @error('product_name')
                            <span class="text-danger">{{$message}}</span>
                        @enderror
                    </div>

                    <div class="col-sm-6 mb-3 mb-sm-0">
                        {{ Form::label('product_company', __('Product Company'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                        <input type="text" class="form-control form-control-user @error('product_company') is-invalid @enderror" id="product_company"
                            placeholder="Enter Product Company" name="product_company" value="{{ old('product_company') ? old('product_company') : $products->product_company }}">
                        @error('product_company')
                            <span class="text-danger">{{$message}}</span>
                        @enderror
                    </div>

                    <div class="col-sm-6 mb-6 mb-3 mb-sm-0">
                        <div class="form-group">
                            {{ Form::label('purchase_rate', __('Purchase Amount'), ['class' => 'form-label']) }}<span class="text-danger pl-1">*</span>
                            <input type="number" class="form-control form-control-user @error('purchase_rate') is-invalid @enderror" id="purchase_rate" 
                                placeholder="Enter Product purchase amount" name="purchase_rate" value="{{ old('purchase_rate') ? old('purchase_rate') : $products->purchase_rate }}">
                            @error('purchase_rate')
                                <span class="text-danger">{{$message}}</span>
                            @enderror
                        </div>
                    </div>
                    <div class="col-sm-6 mb-6 mb-3 mb-sm-0">
                        <div class="form-group">
                            {{ Form::label('price', __('Sale Amount'), ['class' => 'form-label']) }}<span class="text-danger pl-1">*</span>
                            <input type="number" class="form-control form-control-user @error('price') is-invalid @enderror" id="price" 
                                placeholder="Enter Product Sale amount" name="price" value="{{ old('price') ? old('price') : $products->price }}">
                            @error('price')
                                <span class="text-danger">{{$message}}</span>
                            @enderror
                        </div>
                    </div>

                    <div class="col-sm-6 mb-6 mb-3 mb-sm-0">
                        <div class="form-group">
                            {{ Form::label('image', __('Image'), ['class' => 'form-label']) }}<span class="text-danger pl-1">*</span>
                            <input type="text" class="form-control form-control-user @error('image') is-invalid @enderror" id="image" placeholder="Enter image link" name="image" value="{{ old('image') ? old('image') : $products->image }}">
                            @error('image')
                                <span class="text-danger">{{$message}}</span>
                            @enderror
                        </div>
                    </div>
                    <div class="col-sm-6 mb-6 mb-3 mb-sm-0">
                        <div class="form-group">
                            {{ Form::label('description', __('Description'), ['class' => 'form-label']) }}<span class="text-danger pl-1">*</span>
                            <input type="text" class="form-control form-control-user @error('description') is-invalid @enderror" id="description" placeholder="Enter description" name="description" value="{{ old('price') ? old('price') : $products->description }}">
                            @error('description')
                                <span class="text-danger">{{$message}}</span>
                            @enderror
                        </div>
                    </div>
                   
                   

                </div>

                {{-- Save Button --}}
                <button type="submit" class="btn btn-success btn-user btn-block">{{__('Update')}}</button>

            </form>
        </div>
    </div>

</div>


@endsection

 
<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('Blood Management')); ?></h1>
        <a href="<?php echo e(route('blood.index')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-arrow-left fa-sm text-white-50"></i><?php echo e(__('Back')); ?></a>
    </div>

    
    <?php echo $__env->make('common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Donor Details')); ?></h6>
        </div>
        <div class="card-body">
                <div class="form-group row">

                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <?php echo e(Form::label('donor_name', __('Donor Name'), ['class' => 'col-form-label'])); ?>

                        <input readonly class="form-control form-control-user" value="<?php echo e($bloods->donor_name); ?>">
                    </div>

                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <?php echo e(Form::label('donation_date', __('Blood Group'), ['class' => 'col-form-label'])); ?>

                        <select id="blood_group" name="blood_group" class="form-control form-control-user" readonly>
                            <option value="A+" <?php if($bloods->blood_group == 'A+'): ?> selected <?php endif; ?> ><?php echo e(__('A+')); ?></option>
                            <option value="A-" <?php if($bloods->blood_group == 'A-'): ?> selected <?php endif; ?> ><?php echo e(__('A-')); ?></option>
                            <option value="B+" <?php if($bloods->blood_group == 'B+'): ?> selected <?php endif; ?> ><?php echo e(__('B+')); ?></option>
                            <option value="B-" <?php if($bloods->blood_group == 'B-'): ?> selected <?php endif; ?> ><?php echo e(__('B-')); ?></option>
                            <option value="AB+"<?php if($bloods->blood_group == 'AB+'): ?> selected <?php endif; ?> ><?php echo e(__('AB+')); ?></option>
                        </select>
                        
                    </div>

                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <?php echo e(Form::label('donation_date', __('Date of Donation'), ['class' => 'col-form-label'])); ?>

                        <input readonly class="form-control form-control-user" value="<?php echo e($bloods->donation_date); ?>">
                    </div>

                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <?php echo e(Form::label('blood_quandity', __('Quantity (in ml)'), ['class' => 'col-form-label'])); ?>

                        <input readonly class="form-control form-control-user" value="<?php echo e($bloods->blood_quandity); ?>">
                    </div>
                </div>
 
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allianze/Downloads/User-management/resources/views/blood/show.blade.php ENDPATH**/ ?>
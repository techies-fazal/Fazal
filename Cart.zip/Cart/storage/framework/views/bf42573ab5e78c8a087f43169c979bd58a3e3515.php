<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('vendor Management')); ?></h1>
        <a href="<?php echo e(route('vendor.index')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-arrow-left fa-sm text-white-50"></i><?php echo e(__('Back')); ?></a>
    </div>

    
    <?php echo $__env->make('common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Donor Details')); ?></h6>
        </div>
        <div class="card-body">
            <div class="form-group row">
                <div class="col-sm-6 mb-3 mb-sm-0">
                    <?php echo e(Form::label('vendor_name', __('Vendor Name'), ['class' => 'col-form-label'])); ?>

                    <input readonly class="form-control form-control-user" value="<?php echo e($vendors->vendor_name); ?>">
                </div>
                <div class="col-sm-6 mb-3 mb-sm-0">
                    <?php echo e(Form::label('vendor_place', __('Vendor Place'), ['class' => 'col-form-label'])); ?>

                    <input readonly class="form-control form-control-user" value="<?php echo e($vendors->vendor_place); ?>">
                </div>
                <div class="col-sm-6 mb-3 mb-sm-0">
                    <?php echo e(Form::label('vendor_date', __('Vendor Created Date'), ['class' => 'col-form-label'])); ?>

                    <input readonly class="form-control form-control-user" value="<?php echo e($vendors->created_at->format('d M Y')); ?>">
                </div>
            </div>
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allianze/Downloads/Cart/resources/views/vendor/show.blade.php ENDPATH**/ ?>
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('home')); ?>">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Laravel <sup>8</sup></div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <!-- <div class="sidebar-heading">
        Users
    </div> -->

    <!-- Nav Item - Pages Collapse Menu -->
    <?php if(\Auth::user()->is_admin == 1  ): ?>
       
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#product_collapse"
            aria-expanded="true" aria-controls="product_collapse">
            <i class="fab fa-product-hunt"></i>
            <span>Product Management</span>
        </a>
        
        <div id="product_collapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Product Components:</h6>
                    <a class="collapse-item" href="<?php echo e(route('product.create')); ?>">Add</a>
                <a class="collapse-item" href="<?php echo e(route('product.index')); ?>">List</a>
            </div>
        </div>
    </li>

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#stock_collapse"
            aria-expanded="true" aria-controls="stock_collapse">
            <i class="fas fa-wallet"></i>
            <span>Stock Management</span>
        </a>
        
        <div id="stock_collapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Stock Components:</h6>
                    <a class="collapse-item" href="<?php echo e(route('stock.create')); ?>">Add</a>
                <a class="collapse-item" href="<?php echo e(route('stock.index')); ?>">List</a>
            </div>
        </div>
    </li>

<?php endif; ?>

    <?php if(\Auth::user()->is_admin == 0  ): ?>
       
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#vendor_collapse"
                aria-expanded="true" aria-controls="vendor_collapse">
                <i class="fa fa-industry"></i>
                <span>Vendor Management</span>
            </a>
            
            <div id="vendor_collapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header">Vendor Components:</h6>
                    <?php if(\Auth::user()->is_admin == 0 ): ?>
                        <a class="collapse-item" href="<?php echo e(route('vendor.create')); ?>">Add</a>
                    <?php endif; ?>
                    <a class="collapse-item" href="<?php echo e(route('vendor.index')); ?>">List</a>
                </div>
            </div>
        </li>
        
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#product_collapse"
            aria-expanded="true" aria-controls="product_collapse">
            <i class="fab fa-product-hunt"></i>
            <span>Product Management</span>
        </a>
        
        <div id="product_collapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Product Components:</h6>
                <?php if(\Auth::user()->is_admin == 0): ?>
                    <a class="collapse-item" href="<?php echo e(route('product.create')); ?>">Add</a>
                <?php endif; ?>
                <a class="collapse-item" href="<?php echo e(route('product.index')); ?>">List</a>
            </div>
        </div>
    </li>

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#stock_collapse"
            aria-expanded="true" aria-controls="stock_collapse">
            <i class="fas fa-wallet"></i>
            <span>Stock Management</span>
        </a>
        
        <div id="stock_collapse" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Stock Components:</h6>
                <?php if(\Auth::user()->is_admin == 0): ?>
                    <a class="collapse-item" href="<?php echo e(route('stock.create')); ?>">Add</a>
                <?php endif; ?>
                <a class="collapse-item" href="<?php echo e(route('stock.index')); ?>">List</a>
            </div>
        </div>
    </li>


    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
            aria-expanded="true" aria-controls="collapseTwo">
            <i class="fas fa-fw fa-cog"></i>
            <span>Users</span>
        </a>
        
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">User Components:</h6>
                <a class="collapse-item" href="<?php echo e(route('users.index')); ?>">List</a>
                <a class="collapse-item" href="<?php echo e(route('users.create')); ?>">Add</a>
            </div>
        </div>
    </li>
   

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <!-- <div class="sidebar-heading">
        Masters
    </div> -->

    <!-- Nav Item - Pages Collapse Menu -->
    <!-- <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages"
            aria-expanded="true" aria-controls="collapsePages">
            <i class="fas fa-fw fa-folder"></i>
            <span>Pages</span>
        </a>
        <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Login Screens:</h6>
                <a class="collapse-item" href="login.html">Login</a>
                <a class="collapse-item" href="register.html">Register</a>
                <a class="collapse-item" href="forgot-password.html">Forgot Password</a>
                <div class="collapse-divider"></div>
                <h6 class="collapse-header">Other Pages:</h6>
                <a class="collapse-item" href="404.html">404 Page</a>
                <a class="collapse-item" href="blank.html">Blank Page</a>
            </div>
        </div>
    </li> -->
    <?php endif; ?>
    <!-- Divider -->
    <!-- <hr class="sidebar-divider d-none d-md-block"> -->

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul><?php /**PATH /home/allianze/Downloads/Cart/resources/views/common/sidebar.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('Vendor Management')); ?></h1>
        <a href="<?php echo e(route('vendor.index')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-arrow-left fa-sm text-white-50"></i> <?php echo e(__('Back')); ?></a>
    </div>

    
    <?php echo $__env->make('common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Add New Vendor')); ?></h6>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('vendor.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                   
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <div class="form-group">
                            <?php echo e(Form::label('vendor_name', __('Vendor Name'), ['class' => 'form-label'])); ?><span class="text-danger pl-1">*</span>
                            <input type="text" class="form-control form-control-user <?php $__errorArgs = ['vendor_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="vendor_name" placeholder="Enter Vendor Name" name="vendor_name" value="<?php echo e(old('vendor_name')); ?>">
                            <?php $__errorArgs = ['vendor_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-sm-6 mb-6 mb-3 mb-sm-0">
                        <div class="form-group">
                            <?php echo e(Form::label('vendor_place', __('Vendor Place'), ['class' => 'form-label'])); ?><span class="text-danger pl-1">*</span>
                            <input type="text" class="form-control form-control-user <?php $__errorArgs = ['vendor_place'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="vendor_place" placeholder="Enter Vendor Place" name="vendor_place" value="<?php echo e(old('vendor_place')); ?>">
                            <?php $__errorArgs = ['vendor_place'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                   
                   
                </div>

                
                <button type="submit" class="btn btn-success btn-user btn-block"><?php echo e(__('Save')); ?></button>

            </form>
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allianze/Downloads/Cart/resources/views/vendor/add.blade.php ENDPATH**/ ?>
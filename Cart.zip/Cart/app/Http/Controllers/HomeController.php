<?php

namespace App\Http\Controllers;
use App\Models\User;
use App\Models\Vendor;
use App\Models\Product;
use App\Models\Stock;
use Auth;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        
 
        $total_vendors = Vendor::get()->count();
        $total_products = Product::get()->count();
        // $today_blood_count = Blood::get()->where('donation_date', '==', date('Y-m-d'))->count();
        $total_user_count  = User::get()->where('is_admin', '!=', Auth::user()->is_admin)->count();

        return view('home', compact('total_vendors', 'total_products', 'total_user_count'));
    }
}

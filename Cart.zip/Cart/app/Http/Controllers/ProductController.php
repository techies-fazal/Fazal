<?php

namespace App\Http\Controllers;
use App\Models\Product;
use App\Models\Cart;
use DB;

use Illuminate\Http\Request;

class ProductController extends Controller
{
     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $products = Product::all();

       
        return view('product.list', compact('products'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('product.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'product_name' => 'required',
            'purchase_rate' => 'required',
            'image' => 'required',
            'description' => 'required',
            'price' => 'required',
            'product_company' => 'required'
            
        ]);
        
        try {
            DB::beginTransaction();
            // Logic For Save Donor Data

            $create_donor = Product::create([
                'product_name' => $request->product_name,
                'purchase_rate' => $request->purchase_rate,
                'price' => $request->price,
                'image' => $request->image,
                'description' => $request->description,
                'product_company' => $request->product_company
                
            ]);

            if(!$create_donor){
                DB::rollBack();

                return back()->with('error', 'Something went wrong while saving Donor data');
            }

            DB::commit();
            return redirect()->route('product.index')->with('success', 'Product Stored Successfully.');


        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $products =  Product::whereId($id)->first();

        if(!$products){
            return back()->with('error', 'Product Details Not Found');
        }

        return view('product.edit', compact('products'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'product_name' => 'required',
            'purchase_rate' => 'required',
            'price' => 'required',
            'image' => 'required',
            'description' => 'required',
            'product_company' => 'required'
        ]);
        
        try {
            DB::beginTransaction();
            // Logic For Save User Data

            $update_donor = Product::where('id', $id)->update([
                'product_name' => $request->product_name,
                'purchase_rate' => $request->purchase_rate,
                'price' => $request->price,
                'image' => $request->image,
                'description' => $request->description,
                'product_company' => $request->product_company
            ]);

            if(!$update_donor){
                DB::rollBack();

                return back()->with('error', 'Something went wrong while update Product data');
            }

            DB::commit();
            return redirect()->route('product.index')->with('success', 'Product Updated Successfully.');


        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            DB::beginTransaction();

            $delete_donor = Product::whereId($id)->delete();

            if(!$delete_donor){
                DB::rollBack();
                return back()->with('error', 'There is an error while deleting Donor.');
            }

            DB::commit();
            return redirect()->route('product.index')->with('success', 'Product Deleted successfully.');



        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }
    }
}

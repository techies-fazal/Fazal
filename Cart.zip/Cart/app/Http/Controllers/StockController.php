<?php

namespace App\Http\Controllers;
use App\Models\Stock;
use App\Models\Product;
use DB;
use Illuminate\Http\Request;

class StockController extends Controller
{
    
     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $stocks = Stock::get();
        
        return view('stock.list', compact('stocks'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $products = Product::get();
        return view('stock.add', compact('products'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // $request->validate([
        //     'product_id' => 'required',
        //     'stock_qty' => 'required'
            
            
        // ]);



        $this->validate(request(), [
            'product_id' => 'required',
            'stock_qty' => 'required'
        ], [], 
        [
            'product_id' => 'Product',
            'stock_qty' => 'Stock Quantity'
        ]);



        
        try {
            DB::beginTransaction();
            // Logic For Save Donor Data

            $create_donor = Stock::create([
                'product_id' => $request->product_id,
                'stock_qty' => $request->stock_qty
                
            ]);

            if(!$create_donor){
                DB::rollBack();

                return back()->with('error', 'Something went wrong while saving Donor data');
            }

            DB::commit();
            return redirect()->route('stock.index')->with('success', 'Stock Stored Successfully.');


        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $stocks     =  Stock::whereId($id)->first();
        $products = Product::get();

        if(!$stocks){
            return back()->with('error', 'Stock Details Not Found');
        }

        return view('stock.edit', compact('stocks', 'products'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // $request->validate([
        //     'product_id' => 'required',
        //     'stock_qty' => 'required'
        // ]);
        



        $this->validate(request(), [
            'product_id' => 'required',
            'stock_qty' => 'required'
        ], [], 
        [
            'product_id' => 'Product',
            'stock_qty' => 'Stock Quantity'
        ]);


        try {
            DB::beginTransaction();
            // Logic For Save User Data
            
            $update_donor = Stock::where('id', $id)->update([
                'product_id' => $request->product_id,
                'stock_qty' => $request->stock_qty
            ]);

            if(!$update_donor){
                DB::rollBack();

                return back()->with('error', 'Something went wrong while update Stock data');
            }

            DB::commit();
            return redirect()->route('stock.index')->with('success', 'Stock Updated Successfully.');
        

        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            DB::beginTransaction();

            $delete_donor = Stock::whereId($id)->delete();

            if(!$delete_donor){
                DB::rollBack();
                return back()->with('error', 'There is an error while deleting Donor.');
            }

            DB::commit();
            return redirect()->route('stock.index')->with('success', 'Stock Deleted successfully.');



        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }
    }
}

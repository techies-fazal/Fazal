<?php

namespace App\Http\Controllers;
use DB;
use App\Models\Vendor;
use Illuminate\Http\Request;

class VendorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $vendors = Vendor::get();
        return view('vendor.list', compact('vendors'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('vendor.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'vendor_name' => 'required',
            'vendor_place' => 'required'
            
        ]);
        
        try {
            DB::beginTransaction();
            // Logic For Save Donor Data

            $create_donor = Vendor::create([
                'vendor_name' => $request->vendor_name,
                'vendor_place' => $request->vendor_place
                
            ]);

            if(!$create_donor){
                DB::rollBack();

                return back()->with('error', 'Something went wrong while saving Donor data');
            }

            DB::commit();
            return redirect()->route('vendor.index')->with('success', 'Vendor Stored Successfully.');


        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $vendors =  Vendor::whereId($id)->first();
        return view('vendor.show', compact('vendors'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $vendors =  Vendor::whereId($id)->first();

        if(!$vendors){
            return back()->with('error', 'Vendor Details Not Found');
        }

        return view('vendor.edit', compact('vendors'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'vendor_name' => 'required',
            'vendor_place' => 'required'
        ]);
        
        try {
            DB::beginTransaction();
            // Logic For Save User Data

            $update_donor = Vendor::where('id', $id)->update([
                'vendor_name' => $request->vendor_name,
                'vendor_place' => $request->vendor_place
            ]);

            if(!$update_donor){
                DB::rollBack();

                return back()->with('error', 'Something went wrong while update Vendor data');
            }

            DB::commit();
            return redirect()->route('vendor.index')->with('success', 'Donor Updated Successfully.');


        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            DB::beginTransaction();

            $delete_donor = Vendor::whereId($id)->delete();

            if(!$delete_donor){
                DB::rollBack();
                return back()->with('error', 'There is an error while deleting Donor.');
            }

            DB::commit();
            return redirect()->route('vendor.index')->with('success', 'Vendor Deleted successfully.');



        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }
    }
}

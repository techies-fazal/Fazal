@extends('layouts.master')

@section('content')
<link href="//cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css" rel="stylesheet">
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">{{__('Blood Management')}}</h1>
        @if (\Auth::user()->is_admin == 1)
            <a href="{{route('blood.create')}}" class="btn btn-sm btn-primary" ><i class="fas fa-plus"></i> {{__('Add New')}}</a>
        @endif
    </div>

    {{-- Alert Messages --}}
    @include('common.alert')
   
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">{{__('Blood Donors Details')}}</h6>
            
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th scope="col">{{__('SL No')}}</th> 
                            <th scope="col">{{__('Donor name')}}</th>
                            <th scope="col">{{__('Blood Group')}}</th>
                            <th scope="col">{{__('Donation Date')}}</th>
                            <th scope="col">{{__('Quantity (in ml)')}}</th>
                            <th scope="col">{{__('Action')}}</th>
                        </tr>
                    </thead>
                    <tbody>
                    @if ($bloods->count())
                        <?php $sl_no=1;  ?>
                       @foreach ($bloods as $blood)
                            <tr>
                                <td>{{ $sl_no }}</td>
                                <td>{{$blood->donor_name ?? ''}}</td>
                                <td>{{$blood->blood_group ?? ''}}</td>
                                <td>{{$blood->donation_date ?? ''}}</td>
                                <td>{{$blood->blood_quandity ?? ''}}</td>
                                <td style="display: flex">
                                    <a href="{{ route('blood.show', ['blood' => $blood->id]) }}" class="btn btn-primary m-2"><i class="fas fa-eye"></i></a>
                                    @if (\Auth::user()->is_admin == 1)
                                    <a href="{{ route('blood.edit', ['blood' => $blood->id]) }}" class="btn btn-primary m-2">
                                            <i class="fa fa-pen"></i>
                                    </a>
                                    <form method="POST" action="{{ route('blood.destroy', ['blood' => $blood->id]) }}">
                                            @csrf
                                            @method('DELETE')
                                            <button class="btn btn-danger m-2" type="submit">
                                                <i class="fa fa-trash"></i>
                                            </button>
                                    </form>
                                    @endif
                                </td>
                                
                            </tr>
                            <?php $sl_no++;  ?>
                       @endforeach
                       @else
                        <tr>
                            <td colspan="8">
                            <h3 class="text-center">{{__('No Data Availble')}}</h3>
                            </td>
                        </tr>
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>


@endsection
 

@extends('layouts.master')

@section('content')

<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">{{__('Edit Blood Management')}}</h1>
        <a href="{{route('blood.index')}}" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-arrow-left fa-sm text-white-50"></i> {{__('Back')}}</a>
    </div>

    {{-- Alert Messages --}}
    @include('common.alert')
   
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">{{__('Edit Donor')}}</h6>
        </div>
        <div class="card-body">
            <form method="POST" action="{{route('blood.update', ['blood' => $bloods->id])}}">
                @csrf
                @method('PUT')
                <div class="form-group row">

                    {{-- Donor name --}}
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        {{ Form::label('donor_name', __('Donor Name'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                        <input type="text" class="form-control form-control-user @error('donor_name') is-invalid @enderror" id="donor_name"
                            placeholder="Enter Donor Name" name="donor_name" value="{{ old('donor_name') ? old('donor_name') : $bloods->donor_name }}">
                        @error('donor_name')
                            <span class="text-danger">{{$message}}</span>
                        @enderror
                    </div>

                    {{-- Blood Group --}}
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        {{ Form::label('donation_date', __('Blood Group'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                        <select id="blood_group" name="blood_group" class="form-control form-control-user @error('blood_group') is-invalid @enderror" 
                         >
                            <option value="" selected>{{__('Select Blood Group')}}</option>
                            <option value="A+" @if($bloods->blood_group == 'A+') selected @endif >{{__('A+')}}</option>
                            <option value="A-" @if($bloods->blood_group == 'A-') selected @endif >{{__('A-')}}</option>
                            <option value="B+" @if($bloods->blood_group == 'B+') selected @endif >{{__('B+')}}</option>
                            <option value="B-" @if($bloods->blood_group == 'B-') selected @endif >{{__('B-')}}</option>
                            <option value="AB+"@if($bloods->blood_group == 'AB+') selected @endif >{{__('AB+')}}</option>
                        </select>
                        @error('blood_group')
                            <span class="text-danger">{{$message}}</span>
                        @enderror
                    </div>

                    {{-- Date of Donation --}}
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        {{ Form::label('donation_date', __('Date of Donation'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                        <input type="date" class="form-control form-control-user @error('donation_date') is-invalid @enderror" id="donation_date" 
                            placeholder="Enter Donor Name" name="donation_date" value="{{ old('donation_date') ? old('donation_date') : $bloods->donation_date }}">
                        @error('donation_date')
                            <span class="text-danger">{{$message}}</span>
                        @enderror
                    </div>

                    {{-- Quantity (in ml) --}}
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        {{ Form::label('blood_quandity', __('Quantity (in ml)'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                        <input type="text" class="form-control form-control-user @error('blood_quandity') is-invalid @enderror" id="blood_quandity" 
                            placeholder="Enter Donor Name" name="blood_quandity" onkeypress = "return isNumberKey(event)"  value="{{ old('blood_quandity') ? old('blood_quandity') : $bloods->blood_quandity }}">
                        @error('blood_quandity')
                            <span class="text-danger">{{$message}}</span>
                        @enderror
                    </div>
                </div>

                {{-- Save Button --}}
                <button type="submit" class="btn btn-success btn-user btn-block">{{__('Update')}}</button>

            </form>
        </div>
    </div>

</div>


@endsection

 
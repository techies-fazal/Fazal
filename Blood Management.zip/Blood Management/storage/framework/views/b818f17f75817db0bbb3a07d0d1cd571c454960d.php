<?php $__env->startSection('content'); ?>
<link href="//cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css" rel="stylesheet">
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('Blood Management')); ?></h1>
        <?php if(\Auth::user()->is_admin == 1): ?>
            <a href="<?php echo e(route('blood.create')); ?>" class="btn btn-sm btn-primary" ><i class="fas fa-plus"></i> <?php echo e(__('Add New')); ?></a>
        <?php endif; ?>
    </div>

    
    <?php echo $__env->make('common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Blood Donors Details')); ?></h6>
            
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th scope="col"><?php echo e(__('SL No')); ?></th> 
                            <th scope="col"><?php echo e(__('Donor name')); ?></th>
                            <th scope="col"><?php echo e(__('Blood Group')); ?></th>
                            <th scope="col"><?php echo e(__('Donation Date')); ?></th>
                            <th scope="col"><?php echo e(__('Quantity (in ml)')); ?></th>
                            <th scope="col"><?php echo e(__('Action')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if($bloods->count()): ?>
                        <?php $sl_no=1;  ?>
                       <?php $__currentLoopData = $bloods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blood): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($sl_no); ?></td>
                                <td><?php echo e($blood->donor_name ?? ''); ?></td>
                                <td><?php echo e($blood->blood_group ?? ''); ?></td>
                                <td><?php echo e($blood->donation_date ?? ''); ?></td>
                                <td><?php echo e($blood->blood_quandity ?? ''); ?></td>
                                <td style="display: flex">
                                    <a href="<?php echo e(route('blood.show', ['blood' => $blood->id])); ?>" class="btn btn-primary m-2"><i class="fas fa-eye"></i></a>
                                    <?php if(\Auth::user()->is_admin == 1): ?>
                                    <a href="<?php echo e(route('blood.edit', ['blood' => $blood->id])); ?>" class="btn btn-primary m-2">
                                            <i class="fa fa-pen"></i>
                                    </a>
                                    <form method="POST" action="<?php echo e(route('blood.destroy', ['blood' => $blood->id])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-danger m-2" type="submit">
                                                <i class="fa fa-trash"></i>
                                            </button>
                                    </form>
                                    <?php endif; ?>
                                </td>
                                
                            </tr>
                            <?php $sl_no++;  ?>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       <?php else: ?>
                        <tr>
                            <td colspan="8">
                            <h3 class="text-center"><?php echo e(__('No Data Availble')); ?></h3>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allianze/Downloads/Blood Management/resources/views/blood/list.blade.php ENDPATH**/ ?>
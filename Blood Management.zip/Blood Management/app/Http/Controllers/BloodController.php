<?php

namespace App\Http\Controllers;
use App\Models\Blood;
use DB;

use Illuminate\Http\Request;

class BloodController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $bloods= Blood::get();
        return view('blood.list', compact('bloods'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('blood.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'donor_name' => 'required',
            'blood_group' => 'required',
            'donation_date' => 'required',
            'blood_quandity' => 'required'
        ]);
        
        try {
            DB::beginTransaction();
            // Logic For Save Donor Data

            $create_donor = Blood::create([
                'donor_name' => $request->donor_name,
                'blood_group' => $request->blood_group,
                'donation_date' => $request->donation_date,
                'blood_quandity' => $request->blood_quandity,
                
            ]);

            if(!$create_donor){
                DB::rollBack();

                return back()->with('error', 'Something went wrong while saving Donor data');
            }

            DB::commit();
            return redirect()->route('blood.index')->with('success', 'Donor Stored Successfully.');


        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
        $bloods =  Blood::whereId($id)->first();
        return view('blood.show', compact('bloods'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $bloods =  Blood::whereId($id)->first();

        if(!$bloods){
            return back()->with('error', 'Blood Details Not Found');
        }

        return view('blood.edit', compact('bloods'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'donor_name' => 'required',
            'blood_group' => 'required',
            'donation_date' => 'required',
            'blood_quandity' => 'required'
        ]);
        
        try {
            DB::beginTransaction();
            // Logic For Save User Data

            $update_donor = Blood::where('id', $id)->update([
                'donor_name' => $request->donor_name,
                'blood_group' => $request->blood_group,
                'donation_date' => $request->donation_date,
                'blood_quandity' => $request->blood_quandity,
            ]);

            if(!$update_donor){
                DB::rollBack();

                return back()->with('error', 'Something went wrong while update Donor data');
            }

            DB::commit();
            return redirect()->route('blood.index')->with('success', 'Donor Updated Successfully.');


        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            DB::beginTransaction();

            $delete_donor = Blood::whereId($id)->delete();

            if(!$delete_donor){
                DB::rollBack();
                return back()->with('error', 'There is an error while deleting Donor.');
            }

            DB::commit();
            return redirect()->route('blood.index')->with('success', 'Donor Deleted successfully.');



        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }
    }
    
}

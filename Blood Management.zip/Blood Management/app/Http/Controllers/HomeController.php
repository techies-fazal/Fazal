<?php

namespace App\Http\Controllers;
use App\Models\Blood;
use App\Models\User;
use Auth;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        
 
        $blood_count = Blood::get()->count();
        $today_blood_count = Blood::get()->where('donation_date', '==', date('Y-m-d'))->count();
        $user_count  = User::get()->where('is_admin', '!=', Auth::user()->is_admin)->count();

        return view('home', compact('blood_count', 'user_count', 'today_blood_count'));
    }
}

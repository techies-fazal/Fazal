<?php
  
use Illuminate\Support\Facades\Route;
  
use App\Http\Controllers\Auth\AuthController;
  
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [AuthController::class, 'index'])->name('login');
Route::post('post-login', [AuthController::class, 'postLogin'])->name('login.student'); 
Route::get('registration', [AuthController::class, 'registration'])->name('register');
Route::post('post-registration', [AuthController::class, 'postRegistration'])->name('register.post'); 


Route::post('student-registration', [AuthController::class, 'studentRegistration'])->name('register.student'); 
Route::get('dashboard', [AuthController::class, 'dashboard']); 

Route::get('edit', [AuthController::class, 'edit']); 
Route::get('logout', [AuthController::class, 'logout'])->name('logout');

Route::post('teacher-registration', [AuthController::class, 'addteacher'])->name('add.teacher'); 
Route::post('student-registration', [AuthController::class, 'sudentRegistration'])->name('add.student'); 
Route::post('mark-registration', [AuthController::class, 'markRegistration'])->name('add.student_mark'); 

 





## Update
Route::get('student_edit/{id}', [AuthController::class, 'student_edit'])->name('student.edit');
Route::post('student_update/{id}', [AuthController::class, 'student_update'])->name('student.update');

Route::get('mark_edit/{id}', [AuthController::class, 'mark_edit'])->name('mark.edit');
Route::post('mark_update/{id}', [AuthController::class, 'mark_update'])->name('mark.update');



## Delete
Route::get('/student_delete/{id}', [AuthController::class, 'student_destroy'])->name('student.delete');
Route::get('/mark_delete/{id}', [AuthController::class, 'mark_destroy'])->name('mark.delete');


 

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Mark extends Model
{
    use HasFactory;

    public $table = 'marks';

    protected $fillable = [
        'st_name',
        'term',
        'maths',
        'science',
        'history',
             
    ];


    public function mark()
    {
        return $this->belongsTo(Student::class, 'st_name', 'id');
        
    }

    public function termss()
    {
        return $this->belongsTo(Term::class, 'term','id');
        
    }

   
     



}

<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Session;
use App\Models\User;
use App\Models\Student;
use App\Models\Teacher;
use App\Models\Term;
use App\Models\Mark;
use Hash;
use DB;



use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
 
    public function sudentRegistration(Request $request )
    {  

        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'age' => 'required',
            'gender' => 'required',
            'teacher_id' => 'required',
        ]);
  
        if ($validator->fails()) {
           return redirect()->Back()->withInput()->withErrors($validator);
        }
        
        $data = $request->all();

        $data= Student::create([
            'name' => $data['name'],
            'age' => $data['age'],
            'gender' => $data['gender'],
            'teacher_id' => $data['teacher_id'],
             
          ]);

        return redirect("dashboard")->withSuccess('Student added successfully');
    }


    public function student_edit($id){
        if(Auth::check())
        {
            $student = Student::find($id);
            $teachers = Teacher::all();
             
            return view('edit')->with(['student'=>$student,'teachers'=>$teachers]);
        }
     }

     public function student_update(Request $request,$id){
        $data = $request->except('_method','_token','submit');
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'age' => 'required',
            'gender' => 'required',
            'teacher_id' => 'required',
        ]);
  
        if ($validator->fails()) {
           return redirect()->Back()->withInput()->withErrors($validator);
        }
        $subject = Student::find($id);
  
        if($subject->update($data)){
  
           Session::flash('message', 'Update successfully!');
           Session::flash('alert-class', 'alert-success');
           return redirect("dashboard");
        }else{
           Session::flash('message', 'Data not updated!');
           Session::flash('alert-class', 'alert-danger');
        }
  
        return Back()->withInput();
     }



     public function student_destroy($id){
        Student::destroy($id);
  
        Session::flash('message', 'Delete successfully!');
        Session::flash('alert-class', 'alert-success');
        return redirect("dashboard");
     }









    public function addteacher(Request $request)
    {  
        $request->validate([
            'teacher_name' => 'required',
        ]);
           
        $data = $request->all();
        $data= Teacher::create([
            'teacher_name' => $data['teacher_name'],
          ]);
        
        // $check = Teacher::create($data);
         
        return redirect("dashboard")->withSuccess('Teacher added successfully');
    }








    public function markRegistration(Request $request)
    {   

        $validator = Validator::make($request->all(), [
            'st_name' => 'required',
            'term' => 'required',
            'maths' => 'required',
            'science' => 'required',
            'history' => 'required',
        ]);
  
        if ($validator->fails()) {
           return redirect()->Back()->withInput()->withErrors($validator);
        }

        $data = $request->all();

        $data= Mark::create([
            'st_name' => $data['st_name'],
            'term' => $data['term'],
            'maths' => $data['maths'],
            'science' => $data['science'],
            'history' => $data['history'],
             
             
          ]);
        // $check = Mark::create($data);
         
        return redirect("dashboard")->withSuccess('Student Marks added successfully');
    }




    public function mark_edit($id)
    {
        if(Auth::check())
        {
            $mark = Mark::find($id);
            $students = Student::all();
            $terms =Term::all();
            // return view('mark_edit',['mark'=>$mark,'students'=>$students,'terms'=>$terms]);
            return view('mark_edit')->with(['mark'=>$mark,'students'=>$students,'terms'=>$terms]);
            
        }
     }


     public function mark_update(Request $request,$id){
        $data = $request->except('_method','_token','submit');
  
        $validator = Validator::make($request->all(), [
            'st_name' => 'required',
            'term' => 'required',
            'maths' => 'required',
            'science' => 'required',
            'history' => 'required',
        ]);
  
        if ($validator->fails()) {
           return redirect()->Back()->withInput()->withErrors($validator);
        }
        $subject = Mark::find($id);
        
        if($subject->update($data)){
  
           Session::flash('message', 'Update successfully!');
           Session::flash('alert-class', 'alert-success');
           return redirect("dashboard");
        }else{
           Session::flash('message', 'Data not updated!');
           Session::flash('alert-class', 'alert-danger');
        }
        return redirect("dashboard")->withInput();
        // return Back()->withSuccess('Marks Updated successfully')->withInput();
     }



     public function mark_destroy($id){
        Mark::destroy($id);
  
        Session::flash('message', 'Delete successfully!');
        Session::flash('alert-class', 'alert-success');
        return redirect("dashboard");
     }





}

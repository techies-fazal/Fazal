// time out dashboard 

$("document").ready(function(){
    setTimeout(function(){
       $("div.alert").remove();
    }, 3000 ); // 5 secs

});



// add student

$(document).ready(function(){
    $("#card-header").click(function(){
      $("#card-body").toggle();
      $("#card-body-2").hide();
      $("#card-body-3").hide();
    });
  });

// add Teacher
  $(document).ready(function(){
    $("#card-header-2").click(function(){
      $("#card-body-2").toggle();
      $("#card-body").hide();
      $("#card-body-3").hide();
    });
  });

  // add Marks
  $(document).ready(function(){
    $("#card-header-3").click(function(){
      $("#card-body-3").toggle();
      $("#card-body").hide();
      $("#card-body-2").hide();
    });
  });

  $(document).ready(function(){
    $("#card-header-4").click(function(){
      $("#card-body-2").toggle();
      $("#card-body-3").hide();
      $("#card-body").hide();
    });
  });


  $('input[type=number]').on('mousewheel', function(e) {
    $(e.target).blur();
  });
  

  $(document).ready(function(){
    $(".dropdown-toggle").click(function(){
      $(".dropdown-menu").toggle();
       
    });
  });

   
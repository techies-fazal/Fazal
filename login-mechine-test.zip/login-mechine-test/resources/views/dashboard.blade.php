@extends('layout')
@section('content')

<link rel="stylesheet" href="/assets/css/custom.css" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">



<div class="container">
            <div class="row justify-content-center pad-bot ">
                <div class="col-md-8">
                    @if (session('success'))
                        <div class="alert alert-success" role="alert" align="center">
                            {{ session('success') }}
                        </div>
                    @endif
                </div>
            </div> 

            <div class="card">
                  <div class="card-header">
                    <button class="btn btn-success" id="card-header-2">Add Teacher</button>
                    <button class="btn btn-success" id="card-header">Add Student</button>
                    <button class="btn btn-success" id="card-header-3">Add Student Marks</button>
                </div>
                
                <div class="card-body" id="card-body">
                    <form action="{{ route('add.student') }}" method="POST">
                        @csrf
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">Name</label>
                            <div class="col-md-6">
                                <input type="text" id="name" class="form-control" name="name" required autofocus>
                                @if ($errors->has('name'))
                                    <span class="text-danger">{{ $errors->first('name') }}</span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="email_address" class="col-md-4 col-form-label text-md-right">Age</label>
                            <div class="col-md-6">
                                <input type="number" id="age" class="form-control" name="age" required autofocus>
                                @if ($errors->has('age'))
                                    <span class="text-danger">{{ $errors->first('age') }}</span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="gender" class="col-md-4 col-form-label text-md-right">Gender</label>
                            <div class="col-md-6">
                                <input type="radio" name="gender" value="M" required > Male 
                                <input type="radio" name="gender" value="F" required> Female 
                                <input type="radio" name="gender" value="O" required> Other
                                @if ($errors->has('gender'))
                                    <span class="text-danger">{{ $errors->first('gender') }}</span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="place" class="col-md-4 col-form-label text-md-right">Reporting Teacher</label>
                            
                            <select name="teacher_id" id="teacher_id" class="mar-rgt" required autofocus>
                                <option value disabled selected>Select Teacher</option>
                                @foreach($teachers as $teacher)
                                    <option  class="form-control" value="{{$teacher->id}}" name="teacher">{{$teacher->teacher_name}}</option>
                                @endforeach
                            @if ($errors->has('teacher_id'))
                                    <span class="text-danger">{{ $errors->first('teacher_id') }}</span>
                                @endif
                            </select>
                            <button class="btn btn-success" style="padding-right:10px;" id="card-header-4">Add Teacher</button>
                        </div>
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn btn-primary bt-wdt">Add</button>
                        </div>
                    </form>
                </div>

                <div class="card-body" id="card-body-2">
                    <form action="{{ route('add.teacher') }}" method="POST">
                        @csrf
                        <div class="form-group row">
                            <label for="teacher_name" class="col-md-4 col-form-label text-md-right">Teacher Name</label>
                            <div class="col-md-6">
                                <input type="text" id="teacher_name" class="form-control" name="teacher_name" required autofocus>
                                @if ($errors->has('teacher_name'))
                                    <span class="text-danger">{{ $errors->first('teacher_name') }}</span>
                                @endif
                            </div>
                            <div class="col-md-2 ">
                                <button type="submit" class="btn btn-primary bt-wdt">Add</button>
                            </div>
                        </div>
                    </form>
                </div>
                 
                <div class="card-body" id="card-body-3">
                    <form action="{{ route('add.student_mark') }}" method="POST">
                        @csrf
                        <div class="form-group row">
                            <label for="place" class="col-md-4 col-form-label text-md-right">Student Name</label>
                            <select name="st_name" id="st_name" required autofocus>
                                <option value disabled selected>Select Name</option>
                                @foreach($students as $student)
                                    <option  class="form-control" value="{{$student->id}}" required>{{$student->name}}</option>
                                @endforeach
                                @if ($errors->has('st_name'))
                                    <span class="text-danger">{{ $errors->first('st_name') }}</span>
                                @endif
                            </select>
                        </div>
                        <div class="form-group row">
                            <label for="term" class="col-md-4 col-form-label text-md-right">Term</label>
                                <select name="term" id="term" required autofocus>
                                    <option value disabled selected >Select Term</option>
                                    @foreach($terms as $term)
                                        <option  class="form-control" value="{{$term->id}}" required>{{$term->term}}</option>
                                    @endforeach
                                    @if ($errors->has('term'))
                                        <span class="text-danger">{{ $errors->first('term') }}</span>
                                    @endif
                                </select>
                        </div>
                        <div class="form-group row">
                            <label for="place" class="col-md-4 text-md-right">Subject</label>
                                <div class="row pad-lft">
                                    <div class="mar-rgt">
                                        <label>Maths</label>
                                        <div>
                                            <input type="number" id="maths" class="form-control" name="maths" required autofocus>
                                            @if ($errors->has('maths'))
                                                <span class="text-danger">{{ $errors->first('maths') }}</span>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="mar-rgt">
                                        <label>Science</label>
                                        <div>
                                            <input type="number" id="science" class="form-control" name="science" required autofocus>
                                            @if ($errors->has('science'))
                                                <span class="text-danger">{{ $errors->first('science') }}</span>
                                            @endif
                                        </div>
                                    </div>
                                    <div>
                                        <label>History</label>
                                        <div>
                                            <input type="number" id="history" class="form-control" name="history" required autofocus>
                                            @if ($errors->has('history'))
                                                <span class="text-danger">{{ $errors->first('history') }}</span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                        
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary bt-wdt">Add</button>
                            </div>
                        </form>
                  </div>
            </div>

<br>   
            <table>
                <thead>
                    <tr>
                        <th colspan="8" class="ta"><h4>Student Details</h4></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Age</th>
                        <th>Gender</th>
                        <th>Reporting Teacher</th>
                        <th>Action</th>
                    </tr>
                </tbody>

                @if ($students->count())
                    @foreach ($students as $student)
                        <tr>
                            <td>{{$no++ }}</td>
                            <td>{{$student->name}}</td>
                            <td>{{$student->age}}</td>
                            <td>{{$student->gender}}</td>
                            <td>{{$student->teacher->teacher_name}}</td>
                            <td>
                                <a href="{{ route('student.edit',[$student->id]) }}" class="btn btn-success">Edit</a>
                                <a href="{{ route('student.delete',[$student->id]) }}" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                    @endforeach
                @else
                <tr><td colspan="8" ><h3>No Data Availble</h3></td></tr> 
                @endif
            
            </table>
            <br>

            <table class="padd_bot">
                <thead>
                    <tr>
                        <th colspan="9" class="ta"><h4>Students Mark Details</h4></th>
                    </tr>
                </thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Maths</th>
                        <th>Science</th>
                        <th>History</th>
                        <th>Term</th>
                        <th>Total Marks</th>
                        <th>Created On</th>
                        <th>Action</th>
                    </tr>
                    @if ($marks->count())
            @foreach ($marks as $mark)

                <tr>
                    <td>{{$mark->id}}</td>
                    <td>{{$mark->mark->name ??''}}</td>
                    <td>{{$mark->maths}}</td>
                    <td>{{$mark->science}}</td>
                    <td>{{$mark->history}}</td>   
                    <td>{{$mark->termss->term ??''}}</td>
                    <td>{{$mark->maths+$mark->science+$mark->history}}</td>
                    <td>{{date('M d,Y H:s A', strtotime($mark->created_at))}}</td>
                    <td>
                        <a href="{{ route('mark.edit',[$mark->id]) }}" class="btn btn-success">Edit</a>
                        <a href="{{ route('mark.delete',[$mark->id]) }}" class="btn btn-danger">Delete</a>
                    </td>
                </tr>
                @endforeach
                @else
                <tr><td colspan="9" ><h3>No Data Availble</h3></td></tr>
                @endif 
            </table>
             
</div>      






<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script src="{{ URL::asset('assets/js/custom.js') }}"></script>

@endsection

@extends('layout')
@section('content')

<link rel="stylesheet" href="/assets/css/custom.css" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

            <div class="container">
                <div class="row justify-content-center pad-bot ">
                    <div class="col-md-8">
                        @if (session('success'))
                            <div class="alert alert-success" role="alert"  align="center">
                                {{ session('success') }}
                            </div>
                        @endif
                    </div>
                </div>

                <div class="card">
                    <div class="card-header" >
                        <div class="row">
                            <div class="col-sm-2">
                                <h4>Edit Student</h4>
                            </div>
                            <div class="col-sm-10" align="right">              
                                <a href="{{url('dashboard') }}" class="btn btn-success" id="card-header-2" align="right">Back</a>
                            </div>
                        </div>
                    </div>
                
                    <div class="card-body" id="card-body" style="display:block!important;">
                        <form action="{{ route('student.update',[$student->id]) }}" method="POST">
                            @csrf
                            <div class="form-group row">
                                <label for="name" class="col-md-4 col-form-label text-md-right">Name</label>
                                <div class="col-md-6">
                                    <input type="text" id="name" value="{{$student->name}}" class="form-control" name="name" required autofocus>
                                    @if ($errors->has('name'))
                                        <span class="text-danger">{{ $errors->first('name') }}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="email_address" class="col-md-4 col-form-label text-md-right">Age</label>
                                <div class="col-md-6">
                                    <input type="number" id="age"  value="{{$student->age}}"  class="form-control" name="age" required autofocus>
                                    @if ($errors->has('age'))
                                        <span class="text-danger">{{ $errors->first('age') }}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="gender" class="col-md-4 col-form-label text-md-right">Gender</label>
                                <div class="col-md-6">
                                    <input type="radio" name="gender" value="M" {{ $student->gender == 'M' ? 'checked' : '' }} > Male 
                                    <input type="radio" name="gender" value="F" {{ $student->gender == 'F' ? 'checked' : '' }} > Female 
                                    <input type="radio" name="gender" value="O" {{ $student->gender == 'O' ? 'checked' : '' }} > Other
                                    @if ($errors->has('gender'))
                                        <span class="text-danger">{{ $errors->first('gender') }}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="place" class="col-md-4 col-form-label text-md-right">Reporting Teacher</label>
                            
                                <select name="teacher_id" id="teacher_id" required autofocus>
                                <option value disabled selected >Select Teacher</option>
                                @foreach($teachers as $teacher)
                                    <option  class="form-control" value="{{$teacher->id}}" name="teacher"  @if ($teacher->id == $student->teacher_id) selected @endif >{{$teacher->teacher_name}}</option>
                                @endforeach
                                </select>
                            </div>
                            
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary bt-wdt">Add</button>
                            </div>
                        </form>
                    </div>
              </div>
            </div>    

             
       




<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script src="{{ URL::asset('assets/js/custom.js') }}"></script>

@endsection

<?php $__env->startSection('content'); ?>
<link href="//cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css" rel="stylesheet">
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('Designation Management')); ?></h1>
        <?php if(\Auth::user()->is_admin == 1): ?>
            <a href="<?php echo e(route('designation.create')); ?>" class="btn btn-sm btn-primary" ><i class="fas fa-plus"></i> <?php echo e(__('Add New')); ?></a>
        <?php endif; ?>
    </div>

    
    <?php echo $__env->make('common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Designation Details')); ?></h6>
            
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th scope="col"><?php echo e(__('SL No')); ?></th> 
                            <th scope="col"><?php echo e(__('Designation Title')); ?></th>
                            <th scope="col"><?php echo e(__('Designation Name')); ?></th>
                            <th scope="col"><?php echo e(__('Designation Status')); ?></th>
                            
                        </tr>
                    </thead>
                    <tbody>
                    <?php if($designations->count()): ?>
                        <?php $sl_no=1;  ?>
                       <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($sl_no); ?></td>
                                <td><?php echo e($designation->designation_title ?? ''); ?></td>
                                <td><?php echo e($designation->designation_name ?? ''); ?></td>
                                <?php if($designation->designation_status == 0): ?>
                                    <td><?php echo e(__('Active')); ?></td>
                                <?php else: ?>
                                    <td><?php echo e(__('InActive')); ?></td>
                                <?php endif; ?>
                               
                            </tr>
                            <?php $sl_no++;  ?>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       <?php else: ?>
                        <tr>
                            <td colspan="8">
                            <h3 class="text-center"><?php echo e(__('No Data Availble')); ?></h3>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allianze/Downloads/User Designation Management System/resources/views/designation/list.blade.php ENDPATH**/ ?>
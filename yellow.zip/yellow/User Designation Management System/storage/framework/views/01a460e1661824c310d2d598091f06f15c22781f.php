<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('Add Users')); ?></h1>
        <a href="<?php echo e(route('users.index')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-arrow-left fa-sm text-white-50"></i> <?php echo e(__('Back')); ?></a>
    </div>

    
    <?php echo $__env->make('common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="flash-message-user"></div>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Add New User')); ?></h6>
        </div>
        <div class="card-body">
            <!-- <form method="POST" action="<?php echo e(route('users.store')); ?>"> -->
            <form id="user_form"  method="POST">
        
                <?php echo csrf_field(); ?>

                <input type="hidden" id="user_url_id" name="id" value="<?php echo e(route('users.store')); ?>" />
                <input type="hidden" id="user_back_url" name="id" value="<?php echo e(route('users.index')); ?>" />

                <div class="form-group row">

                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <?php echo e(Form::label('name', __('Name'), ['class' => 'col-form-label'])); ?><span class="text-danger pl-1">*</span>
                        <input type="text" class="form-control" placeholder="Enter Name" id="name" name="name">
                        <span class="text-danger" id="error_name"></span>
                    </div>
                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <?php echo e(Form::label('email', __('Email'), ['class' => 'col-form-label'])); ?><span class="text-danger pl-1">*</span>
                        <input type="text" class="form-control" placeholder="Enter Email" id="email" name="email" >
                        <span class="text-danger" id="error_email"></span>
                    </div>
                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <?php echo e(Form::label('contact_no', __(' Contact Number,'), ['class' => 'col-form-label'])); ?><span class="text-danger pl-1">*</span>
                        <input type="number" class="form-control" placeholder="Enter Contact No" id="contact_no" name="contact_no">
                        <span class="text-danger" id="error_contact_no"></span>
                    </div>
                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <?php echo e(Form::label('alt_contact', __('Alternative Contact Number'), ['class' => 'col-form-label'])); ?><span class="text-danger pl-1">*</span>
                        <input type="number" class="form-control" placeholder="Enter alt_contact" id="alt_contact" name="alt_contact"  >
                        <span class="text-danger" id="error_alt_contact"></span>
                    </div>
                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <?php echo e(Form::label('address', __('Address'), ['class' => 'col-form-label'])); ?><span class="text-danger pl-1">*</span>
                        <textarea name="address" id="address" cols="20" rows="4"  placeholder="Enter Address" class="form-control form-control-user"></textarea>
                        <span class="text-danger" id="error_address"></span>
                    </div>
                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <?php echo e(Form::label('status', __('Designation'), ['class' => 'col-form-label'])); ?><span class="text-danger pl-1">*</span>
                        <select id="designation" name="designation" class="form-control form-control-user">
                            <option value="" selected><?php echo e(__('Select Designation')); ?></option>
                            <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($designation->id); ?>"><?php echo e($designation->designation_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span class="text-danger" id="error_designation"></span>
                    </div>

                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <?php echo e(Form::label('status', __('User Status'), ['class' => 'col-form-label'])); ?><span class="text-danger pl-1">*</span>
                        <select id="status" name="status" class="form-control form-control-user">
                            <option value="" selected><?php echo e(__('Select User Status')); ?></option>
                            <option value="0"><?php echo e(__('Active')); ?></option>
                            <option value="1"><?php echo e(__('Inactive')); ?></option>
                        </select>
                        <span class="text-danger" id="error_status"></span>
                    </div>

                     

                </div>

                
                <button type="submit" class="btn btn-success btn-user btn-block"id="submit_user" value="create"><?php echo e(__('Save')); ?></button>

            </form>
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allianze/Downloads/User Designation Management System/resources/views/users/add.blade.php ENDPATH**/ ?>
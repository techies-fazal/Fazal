<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('Edit Blood Management')); ?></h1>
        <a href="<?php echo e(route('blood.index')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-arrow-left fa-sm text-white-50"></i> <?php echo e(__('Back')); ?></a>
    </div>

    
    <?php echo $__env->make('common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Edit Designation')); ?></h6>
        </div>
        <div class="card-body">
       <form action="<?php echo e(route('designation.update',$designations->id)); ?>" method="POST">
       <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('PATCH')); ?>

            <!-- <form method="POST" action="<?php echo e(route('designation.update', ['designations' => $designations->id])); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?> -->

                <div class="form-group row">
                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <?php echo e(Form::label('designation_title', __('Designation Title'), ['class' => 'col-form-label'])); ?><span class="text-danger pl-1">*</span>
                        <input type="text" class="form-control form-control-user <?php $__errorArgs = ['designation_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('designations_name') ? old('designations_name') : $designations->designations_name); ?>" id="designation_title" placeholder="Enter Designation Name" name="designation_title" >
                        <?php $__errorArgs = ['designation_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <?php echo e(Form::label('designation_name', __('Designation Name'), ['class' => 'col-form-label'])); ?><span class="text-danger pl-1">*</span>
                        <input type="text" class="form-control form-control-user <?php $__errorArgs = ['designation_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="designation_name" placeholder="Enter Designation Name" name="designation_name" value="<?php echo e(old('designation_name')); ?>">
                        <?php $__errorArgs = ['designation_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <?php echo e(Form::label('Blood Group', __('Designation Status'), ['class' => 'col-form-label'])); ?><span class="text-danger pl-1">*</span>
                        <select id="designation_status" name="designation_status" class="form-control form-control-user <?php $__errorArgs = ['designation_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="" selected><?php echo e(__('Select Blood Group')); ?></option>
                            <option value="0" <?php if($designations->designation_status == 0): ?> selected <?php endif; ?>><?php echo e(__('Active')); ?></option>
                            <option value="1" <?php if($designations->designation_status == 1): ?> selected <?php endif; ?>><?php echo e(__('Inactive')); ?></option>
                        </select>
                        <?php $__errorArgs = ['designation_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
              
                     
                </div>

                
                <button type="submit" class="btn btn-success btn-user btn-block" value="<?php echo e($designations->id); ?>" id="update"><?php echo e(__('Update')); ?></button>

            </form>
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allianze/Downloads/User Designation Management System/resources/views/designation/edit.blade.php ENDPATH**/ ?>
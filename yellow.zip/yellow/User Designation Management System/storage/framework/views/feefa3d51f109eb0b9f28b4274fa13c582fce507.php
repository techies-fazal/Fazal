<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('Users')); ?></h1>
        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-sm btn-primary" ><i class="fas fa-plus"></i> <?php echo e(__('Add New')); ?></a>
    </div>
    <div id="flash-message-delete"></div>
    
    <?php echo $__env->make('common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('All Users')); ?></h6>
            <div class="" align="right">
                <select name="" id="select_desi" class="btn btn-sm btn-primary"  onchange="filter(this.value)">
                <option value="" selected><?php echo e(__('Filter by Designation')); ?></option>
                    <?php $__currentLoopData = $desig; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($designation->id); ?>"><?php echo e($designation->designation_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <select id="select_status" name="status" class="btn btn-sm btn-primary">
                    <option value="" selected><?php echo e(__('Filter by Status')); ?></option>
                    <option value="0"><?php echo e(__('Active')); ?></option>
                    <option value="1"><?php echo e(__('Inactive')); ?></option>
                </select>
            </div>
           
        </div>


        <div id="campaign">
           
    
    </div> 


        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th><?php echo e(__('SL No')); ?></th>
                            <th><?php echo e(__('Name')); ?></th>
                            <th><?php echo e(__('Email')); ?></th>
                            <th><?php echo e(__('Contact No')); ?></th>
                            <th><?php echo e(__('Alternative Contact No')); ?></th>
                            <th><?php echo e(__('Designation')); ?></th>
                            <th><?php echo e(__('Status')); ?></th>
                            <th><?php echo e(__('Action')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if($users->count()): ?>
                        <?php $sl_no=1;  ?>
                       <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                               <td><?php echo e($sl_no); ?></td>
                               <td><?php echo e($user->name ?? ''); ?></td>
                               <td><?php echo e($user->email ?? ''); ?></td>
                               <td><?php echo e($user->contact_no ?? ''); ?></td>
                               <td><?php echo e($user->alt_contact ?? ''); ?></td>
                               <td><?php echo e($user->designations->designation_name ?? ''); ?></td>
                               <?php if($user->status == 0): ?>
                                    <td><button class="btn btn-success"><?php echo e(__('Active')); ?></button></td>
                                <?php else: ?>
                                <td><button class="btn btn-warning"><?php echo e(__('InActive')); ?></button></td>
                                <?php endif; ?>
                               <td style="display: flex">
                                    <a href="<?php echo e(route('users.edit', ['user' => $user->id])); ?>" class="btn btn-primary m-2"><i class="fa fa-pen"></i></a>
                                    <button class="btn btn-danger m-2" id="delete" data-id="<?php echo e($user->id); ?>" type="submit"><i class="fa fa-trash"></i></button>
                               </td>
                           </tr>
                           <?php $sl_no++;  ?>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       <?php else: ?>
                        <tr>
                            <td colspan="8">
                            <h3 class="text-center"><?php echo e(__('No Data Availble')); ?></h3>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allianze/Downloads/User Designation Management System/resources/views/users/list.blade.php ENDPATH**/ ?>
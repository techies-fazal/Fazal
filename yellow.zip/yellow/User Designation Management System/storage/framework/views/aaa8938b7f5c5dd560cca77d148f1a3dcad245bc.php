<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('Edit Users')); ?></h1>
        <a href="<?php echo e(route('users.index')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-arrow-left fa-sm text-white-50"></i> <?php echo e(__('Back')); ?></a>
    </div>
<div id="flash-message-edit"></div>
    
    <?php echo $__env->make('common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Edit User')); ?></h6>
        </div>
        <div class="card-body">
            <!-- <form method="POST" action="<?php echo e(route('users.store')); ?>"> -->
            <form id="user_update_form"  method="POST">
        
                <?php echo csrf_field(); ?>

                <input type="hidden" id="update_url_id" name="id" value="<?php echo e(route('users.update',$user->id)); ?>" />
                <input type="hidden" id="update_back_url" name="id" value="<?php echo e(route('users.index')); ?>" />

                <div class="form-group row">

                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <?php echo e(Form::label('name', __('Name'), ['class' => 'col-form-label'])); ?><span class="text-danger pl-1">*</span>
                        <input type="text" class="form-control" placeholder="Enter Name" name="name" value="<?php echo e($user->name); ?>">
                         <span class="text-danger" id="error_name"></span>
                    </div>


                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <?php echo e(Form::label('email', __('Email'), ['class' => 'col-form-label'])); ?><span class="text-danger pl-1">*</span>
                        <input type="text" class="form-control" placeholder="Enter Email" value="<?php echo e($user->email); ?>" name="email" >
                         <span class="text-danger" id="error_email"></span>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <?php echo e(Form::label('contact_no', __(' Contact Number,'), ['class' => 'col-form-label'])); ?><span class="text-danger pl-1">*</span>
                        <input type="number" class="form-control" placeholder="Enter Contact No" value="<?php echo e($user->contact_no); ?>" name="contact_no">
                         <span class="text-danger" id="error_contact_no"></span>
                        
                    </div>
                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <?php echo e(Form::label('alt_contact', __('Alternative Contact Number'), ['class' => 'col-form-label'])); ?><span class="text-danger pl-1">*</span>
                        <input type="number" class="form-control" placeholder="Enter Alternative Contact Number" value="<?php echo e($user->alt_contact); ?>" name="alt_contact"  >
                         <span class="text-danger" id="error_alt_contact"></span>
                    </div>
                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <?php echo e(Form::label('address', __('Address'), ['class' => 'col-form-label'])); ?><span class="text-danger pl-1">*</span>
                        <textarea value="<?php echo e($user->address); ?>" name="address" id="address" cols="20" rows="4"  placeholder="Enter Address"  class="form-control form-control-user"><?php echo e($user->address); ?></textarea>
                         <span class="text-danger" id="error_address"></span>
                    </div>
                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <?php echo e(Form::label('status', __('Designation'), ['class' => 'col-form-label'])); ?><span class="text-danger pl-1">*</span>
                        <select id="designation" name="designation" class="form-control form-control-user">
                            <option value="" selected><?php echo e(__('Select Designation')); ?></option>
                            <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($designation->id ?? ''); ?>" <?php echo e(($designation->designation_status == $user->status) ? 'selected' : ''); ?> ><?php echo e($designation->designation_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </select>
                         <span class="text-danger" id="error_designation"></span>
                    </div>

                    
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <?php echo e(Form::label('status', __('User Status'), ['class' => 'col-form-label'])); ?><span class="text-danger pl-1">*</span>
                        <select id="status" name="status" class="form-control form-control-user">
                            <option value="" selected><?php echo e(__('Select User Status')); ?></option>
                            <option value="0" <?php if($user->status == 0): ?> selected <?php endif; ?>><?php echo e(__('Active')); ?></option>
                            <option value="1" <?php if($user->status == 1): ?> selected <?php endif; ?>><?php echo e(__('Inactive')); ?></option>
                        </select>
                         <span class="text-danger" id="error_status"></span>
                    </div>

                     

                </div>

                
                <button type="submit" data-id="<?php echo e($user->id); ?>" class="btn btn-success btn-user btn-block" id="submit_user_update" value="create"><?php echo e(__('Save')); ?></button>

            </form>
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allianze/Downloads/User Designation Management System/resources/views/users/edit.blade.php ENDPATH**/ ?>
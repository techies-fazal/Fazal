

$(document).ready(function() {

    //Designation Insert Code
    $('#submit_designation').click(function(e) {
        e.preventDefault();

        
        var name       =  $("#designation_name").val();
        var title      = $("#designation_title").val();
        var status      = $("#designation_status").val();
    
        if(name == "") {
            $("#error_name").html('<div class="text-danger"> Designation Name is required </div>');
            
        }
        else{
            $("#error_name").empty();
        }
    
        if(title == "") {
            $("#error_title").html('<div class="text-danger"> Designation Title is required </div>');
           
        }
        else{
            $("#error_title").empty();
        }
        if(status == "") {
            $("#error_status").html('<div class="text-danger"> Designation Status is required </div>');
            return false;
        }
        else{
            $("#error_status").empty();
        }


       
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
            url: "/designationStore",
            type: "post",
            dataType: "json",
            data: $('#designation_form').serialize(),
            success: function(response) {
                $("#designation_form")[0].reset();
                    $("#flash-message-designation").html("<div class='alert alert-success alert-dismissible'><button type='button' class='close' data-dismiss='alert'>×</button>" + response.success + "</div>").fadeIn('slow');
                    $('#flash-message-designation').delay(3000).fadeOut('slow');
                 
                 
            }
        });
    });


    
    //User Insert Code
    $('#submit_user').click(function(e) {
        e.preventDefault();
        

        var name        =  $("#name").val();
        var email       =  $("#email").val();
        var contact_no  =  $("#contact_no").val();
        var alt_contact =  $("#alt_contact").val();
        var address     =  $("#address").val();
        var designation = $("#designation").val();
        var status      = $("#status").val();
    
        if(name == "") {
            $("#error_name").html('<div class="text-danger"> Name is required </div>');
            
        }
        else{
            $("#error_name").empty();
        }
    
        if(email == "") {
            $("#error_email").html('<div class="text-danger"> Email is required </div>');
           
        }
        else{
            $("#error_email").empty();
        }
        if(contact_no == "") {
            $("#error_contact_no").html('<div class="text-danger"> Contact No is required </div>');
            
        }
        else{
            $("#error_contact_no").empty();
        }
        if(alt_contact == "") {
            $("#error_alt_contact").html('<div class="text-danger"> Alternative No is required </div>');
           
        }
        else{
            $("#error_alt_contact").empty();
        }
        if(address == "") {
            $("#error_address").html('<div class="text-danger"> Address is required </div>');
            
        }
        else{
            $("#error_address").empty();
        }
        if(designation == "") {
            $("#error_designation").html('<div class="text-danger"> Designation is required </div>');
            
        }
        else{
            $("#error_designation").empty();
        }
        if(status == "") {
            $("#error_status").html('<div class="text-danger"> Status is required </div>');
            return false;
        }
        else{
            $("#error_status").empty();
        }


        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
            url:  "/user_store",
            type: "post",
            dataType: "json",
            data: $('#user_form').serialize(),
            success: function(response) {
                
                $("#user_form")[0].reset();
                        
                $("#flash-message-user").html("<div class='alert alert-success alert-dismissible'><button type='button' class='close' data-dismiss='alert'>×</button>" + response.success + "</div>").fadeIn('slow');
               
                $('#flash-message-user').delay(3000).fadeOut('slow');
               
            }
        });
    });



    // User Form Update

    $('#submit_user_update').click(function(e) {
        e.preventDefault();
        var id = $('#submit_user_update').data('id');




        var name        =  $("#name").val();
        var email       =  $("#email").val();
        var contact_no  =  $("#contact_no").val();
        var alt_contact =  $("#alt_contact").val();
        var address     =  $("#address").val();
        var designation = $("#designation").val();
        var status      = $("#status").val();
    
        if(name == "") {
            $("#error_name").html('<div class="text-danger"> Name is required </div>');
            
        }
        else{
            $("#error_name").empty();
        }
    
        if(email == "") {
            $("#error_email").html('<div class="text-danger"> Email is required </div>');
           
        }
        else{
            $("#error_email").empty();
        }
        if(contact_no == "") {
            $("#error_contact_no").html('<div class="text-danger"> Contact No is required </div>');
            
        }
        else{
            $("#error_contact_no").empty();
        }
        if(alt_contact == "") {
            $("#error_alt_contact").html('<div class="text-danger"> Alternative No is required </div>');
           
        }
        else{
            $("#error_alt_contact").empty();
        }
        if(address == "") {
            $("#error_address").html('<div class="text-danger"> Address is required </div>');
            
        }
        else{
            $("#error_address").empty();
        }
        if(designation == "") {
            $("#error_designation").html('<div class="text-danger"> Designation is required </div>');
            
        }
        else{
            $("#error_designation").empty();
        }
        if(status == "") {
            $("#error_status").html('<div class="text-danger"> Status is required </div>');
            return false;
        }
        else{
            $("#error_status").empty();
        }


        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
            url: "/update/"+id,
            // url:"{{ route('update') }"+id,
            type: "post",
            dataType: "json",
            data: $('#user_update_form').serialize(),
            success: function(response) {
                
                    
                if(response)
                {
                    $("#flash-message-edit").html("<div class='alert alert-success alert-dismissible'><button type='button' class='close' data-dismiss='alert'>×</button>" + response.success + "</div>").fadeIn('slow');
                    window.location.href = url(user.index);
                }
               
            }
        });
    });






     // delete user code goes here
     $(document).on('click', '#delete', function() {
       
        var id = $('#delete').data('id');
       
        
 
        if(confirm('Are you sure you want delete??')){

           
            $.ajax({
                url: "/delete/"+id,
                type: "get",
                dataType: 'json',
                data: {
                    "_token": "{{ csrf_token() }}",
                    "id": $(this).data('id')
                },
                success: function(response) {
                    window.location.reload();
                }
            });
        }
    })
   


   
    

    // $('#select_desi,#select_status').change(function(){
    //     empTable.draw();
    //  });



});



function filter(data)
{
    var val = data;
    
    $.ajax({
    type: "POST",
    url: "/get_filter/"+val,
    data: { id : val },
        success:function(campaigns)
        {
            $("#campaign").html(campaigns);
        }
    });
}



function printErrorMsg (msg) {
    $(".print-error-msg").find("ul").html('');
    $(".print-error-msg").css('display','block');
    $.each( msg, function( key, value ) {
        $(".print-error-msg").find("ul").append('<li>'+value+'</li>');
    });
}













































$("#createBtn").click(function(event) {
   
    event.preventDefault();
    $(".error").remove();
    $(".alert").remove();

    var name       =  $("#designation_name").val();
    var title      = $("#designation_title").val();
    var status      = $("#designation_status").val();

    if(name == "") {
        $("#designation_name").after('<div class="text-danger"> Designation Name is required </div>');
        
    }

    if(title == "") {
        $("#designation_title").after('<div class="text-danger"> Designation Title is required </div>');
        
    }
    if(status == "") {
        $("#designation_status").after('<div class="text-danger"> Designation Status is required </div>');
        return false;
    }

    var form_data   =       $("#postForm").serialize();

    // if post id exist
    if($("#id_hidden").val() !="") {
        updatePost(form_data);
    }

    // else create post
    else {
        createPost(form_data);
    }
});


// create new post
function createPost(form_data) {
   
    $.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    
    $.ajax({
        url: "{{ route('designation.store') }}",
        method: 'post',
        data: form_data,
        dataType: 'json',

        beforeSend:function() {
            $("#createBtn").addClass("disabled");
            $("#createBtn").text("Processing..");
        },

        success:function(res) {
            
            $("#createBtn").removeClass("disabled");
            $("#createBtn").text("Save");

            if(res.status == "success") {
                $(".result").html("<div class='alert alert-success alert-dismissible'><button type='button' class='close' data-dismiss='alert'>×</button>" + res.message+ "</div>");
            }

            else if(res.status == "failed") {
                $(".result").html("<div class='alert alert-danger alert-dismissible'><button type='button' class='close' data-dismiss='alert'>×</button>" + res.message+ "</div>");
            }
        }
    });
}

























$(document).ready(function() {
    // Update Data
 
        $.ajaxSetup({
            headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#savedata').on('submit', function(e){
            e.preventDefault();

            // var usr_id = $('#emp_id').val();

            $.ajax({
                type: "POST",
                // url: "/profile/edit/" + usr_id,
                url: "{{ route('designation.store') }}",
                dataType: $('#savedata').serialize(),
                success: function (response) {
                    console.log(response);
                    alert("Data Updated");
                    location.reload();
                },
                error:function(error){
                    console.log(error);
                }
            });
        });

    });


















if ($("#designation_form").length > 0) {
    $("#designation_form").validate({
        rules: {
            designation_title: {
                required: true,
                maxlength: 50
            },
            designation_name: {
                required: true,
                maxlength: 50
            },
            designation_status: {
                required: true,
                maxlength: 50
            }, 
        
        },
        messages: {
            designation_title: {
                required: "Please enter name",
                maxlength: "Your name maxlength should be 50 characters long."
            },
            designation_name: {
                required: "Please enter name",
                maxlength: "Your name maxlength should be 50 characters long."
            },   
            designation_status: {
                required: "Please enter name",
                maxlength: "Select status"
            },
        },

    submitHandler: function(form) {
    $.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    
    $('#submit').html('Please Wait...');
    $("#submit"). attr("disabled", true);
    
    $.ajax({
        url: "{{url('store')}}",
        type: "POST",
        data: $('#designation_form').serialize(),
        success: function( response ) {
            $('#submit').html('Submit');
            $("#submit"). attr("disabled", false);
            alert('Ajax form has been submitted successfully');
        document.getElementById("designation_form").reset(); 
        }
    });
    }
    })
}





if ($("#designation_form").length > 0) {
    $("#designation_form").validate({
        rules: {
            designation_title: {
                required: true,
                maxlength: 50
            },
            designation_name: {
                required: true,
                maxlength: 50
            },
            designation_status: {
                required: true,
                maxlength: 50
            }, 
        
        },
        messages: {
            designation_title: {
                required: "Please enter name",
                maxlength: "Your name maxlength should be 50 characters long."
            },
            designation_name: {
                required: "Please enter name",
                maxlength: "Your name maxlength should be 50 characters long."
            },   
            designation_status: {
                required: "Please enter name",
                maxlength: "Select status"
            },
        },

    submitHandler: function(form) {
    $.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    
    $('#update').html('Please Wait...');
    $("#update"). attr("disabled", true);
    
    $.ajax({
        url: "{{url('update')}}",
        type: "POST",
        data: $('#designation_form').serialize(),
        success: function( response ) {
            $('#update').html('update');
            $("#update"). attr("disabled", false);
            alert('Ajax form has been submitted successfully');
        document.getElementById("designation_form").reset(); 
        }
    });
    }
    })
}








// <script type="text/javascript">
//   $(function () {
     
//       $.ajaxSetup({
//           headers: {
//               'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
//           }
//     });
    
//     var table = $('.data-table').DataTable({
//         processing: true,
//         serverSide: true,
//         ajax: "{{ route('ajaxposts.index') }}",
//         columns: [
//             {data: 'DT_RowIndex', name: 'DT_RowIndex'},
//             {data: 'title', name: 'title'},
//             {data: 'description', name: 'description'},
//             {data: 'action', name: 'action', orderable: false, searchable: false},
//         ]
//     });
     
//     $('#createNewPost').click(function () {
//         $('#savedata').val("create-post");
//         $('#id').val('');
//         $('#postForm').trigger("reset");
//         $('#modelHeading').html("Create New Post");
//         $('#ajaxModelexa').modal('show');
//     });
    
//     $('body').on('click', '.editPost', function () {
//       var id = $(this).data('id');
//       $.get("{{ route('ajaxposts.index') }}" +'/' + id +'/edit', function (data) {
//           $('#modelHeading').html("Edit Post");
//           $('#savedata').val("edit-user");
//           $('#ajaxModelexa').modal('show');
//           $('#id').val(data.id);
//           $('#title').val(data.title);
//           $('#description').val(data.description);
//       })
//    });
    




//     $('#savedata').click(function (e) {
//         e.preventDefault();
//         $(this).html('Sending..');
    
//         $.ajax({
//           data: $('#postForm').serialize(),
//           url: "{{ route('designation.store') }}",
//           type: "POST",
//           dataType: 'json',
//           success: function (data) {
     
//               $('#postForm').trigger("reset");
//               $('#ajaxModelexa').modal('hide');
//               table.draw();
         
//           },
//           error: function (data) {
//               console.log('Error:', data);
//               $('#savedata').html('Save Changes');
//           }
//       });
//     });
    
//     $('body').on('click', '.deletePost', function () {
     
//         var id = $(this).data("id");
//         confirm("Are You sure want to delete this Post!");
      
//         $.ajax({
//             type: "DELETE",
//             url: "{{ route('ajaxposts.store') }}"+'/'+id,
//             success: function (data) {
//                 table.draw();
//             },
//             error: function (data) {
//                 console.log('Error:', data);
//             }
//         });
//     });
     
//   });
// </script>




@extends('layouts.master')

@section('content')
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">{{__('Users')}}</h1>
        <a href="{{route('users.create')}}" class="btn btn-sm btn-primary" ><i class="fas fa-plus"></i> {{__('Add New')}}</a>
    </div>
    <div id="flash-message-delete"></div>
    {{-- Alert Messages --}}
    @include('common.alert')
   
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">{{__('All Users')}}</h6>
            <div class="" align="right">
                <select name="" id="select_desi" class="btn btn-sm btn-primary"  onchange="filter(this.value)">
                <option value="" selected>{{__('Filter by Designation')}}</option>
                    @foreach ($desig as $designation)
                        <option value="{{$designation->id}}">{{$designation->designation_name}}</option>
                    @endforeach
                </select>
                <select id="select_status" name="status" class="btn btn-sm btn-primary">
                    <option value="" selected>{{__('Filter by Status')}}</option>
                    <option value="0">{{__('Active')}}</option>
                    <option value="1">{{__('Inactive')}}</option>
                </select>
            </div>
           
        </div>


        <div id="campaign">
           
    
    </div> 


        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>{{__('SL No')}}</th>
                            <th>{{__('Name')}}</th>
                            <th>{{__('Email')}}</th>
                            <th>{{__('Contact No')}}</th>
                            <th>{{__('Alternative Contact No')}}</th>
                            <th>{{__('Designation')}}</th>
                            <th>{{__('Status')}}</th>
                            <th>{{__('Action')}}</th>
                        </tr>
                    </thead>
                    <tbody>
                    @if ($users->count())
                        <?php $sl_no=1;  ?>
                       @foreach ($users as $user)
                           <tr>
                               <td>{{ $sl_no }}</td>
                               <td>{{$user->name ?? ''}}</td>
                               <td>{{$user->email ?? ''}}</td>
                               <td>{{$user->contact_no ?? ''}}</td>
                               <td>{{$user->alt_contact ?? ''}}</td>
                               <td>{{$user->designations->designation_name ?? ''}}</td>
                               @if($user->status == 0)
                                    <td><button class="btn btn-success">{{__('Active')}}</button></td>
                                @else
                                <td><button class="btn btn-warning">{{__('InActive')}}</button></td>
                                @endif
                               <td style="display: flex">
                                    <a href="{{ route('users.edit', ['user' => $user->id]) }}" class="btn btn-primary m-2"><i class="fa fa-pen"></i></a>
                                    <button class="btn btn-danger m-2" id="delete" data-id="{{$user->id}}" type="submit"><i class="fa fa-trash"></i></button>
                               </td>
                           </tr>
                           <?php $sl_no++;  ?>
                       @endforeach
                       @else
                        <tr>
                            <td colspan="8">
                            <h3 class="text-center">{{__('No Data Availble')}}</h3>
                            </td>
                        </tr>
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>


@endsection
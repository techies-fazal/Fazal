@extends('layouts.master')

@section('content')

<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">{{__('Add Users')}}</h1>
        <a href="{{route('users.index')}}" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-arrow-left fa-sm text-white-50"></i> {{__('Back')}}</a>
    </div>

    {{-- Alert Messages --}}
    @include('common.alert')
    <div id="flash-message-user"></div>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">{{__('Add New User')}}</h6>
        </div>
        <div class="card-body">
            <!-- <form method="POST" action="{{route('users.store')}}"> -->
            <form id="user_form"  method="POST">
        
                @csrf

                <input type="hidden" id="user_url_id" name="id" value="{{route('users.store')}}" />
                <input type="hidden" id="user_back_url" name="id" value="{{route('users.index')}}" />

                <div class="form-group row">

                    {{-- Name --}}
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        {{ Form::label('name', __('Name'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                        <input type="text" class="form-control" placeholder="Enter Name" id="name" name="name">
                        <span class="text-danger" id="error_name"></span>
                    </div>
                    {{-- Email --}}
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        {{ Form::label('email', __('Email'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                        <input type="text" class="form-control" placeholder="Enter Email" id="email" name="email" >
                        <span class="text-danger" id="error_email"></span>
                    </div>
                    {{--  Contact Number, --}}
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        {{ Form::label('contact_no', __(' Contact Number,'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                        <input type="number" class="form-control" placeholder="Enter Contact No" id="contact_no" name="contact_no">
                        <span class="text-danger" id="error_contact_no"></span>
                    </div>
                    {{-- Alternative Contact Number --}}
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        {{ Form::label('alt_contact', __('Alternative Contact Number'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                        <input type="number" class="form-control" placeholder="Enter alt_contact" id="alt_contact" name="alt_contact"  >
                        <span class="text-danger" id="error_alt_contact"></span>
                    </div>
                    {{-- Address --}}
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        {{ Form::label('address', __('Address'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                        <textarea name="address" id="address" cols="20" rows="4"  placeholder="Enter Address" class="form-control form-control-user"></textarea>
                        <span class="text-danger" id="error_address"></span>
                    </div>
                    {{-- Designation --}}
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        {{ Form::label('status', __('Designation'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                        <select id="designation" name="designation" class="form-control form-control-user">
                            <option value="" selected>{{__('Select Designation')}}</option>
                            @foreach($designations as $designation)
                                <option value="{{$designation->id}}">{{$designation->designation_name}}</option>
                            @endforeach
                        </select>
                        <span class="text-danger" id="error_designation"></span>
                    </div>

                    {{-- User Status --}}
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        {{ Form::label('status', __('User Status'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                        <select id="status" name="status" class="form-control form-control-user">
                            <option value="" selected>{{__('Select User Status')}}</option>
                            <option value="0">{{__('Active')}}</option>
                            <option value="1">{{__('Inactive')}}</option>
                        </select>
                        <span class="text-danger" id="error_status"></span>
                    </div>

                     

                </div>

                {{-- Save Button --}}
                <button type="submit" class="btn btn-success btn-user btn-block"id="submit_user" value="create">{{__('Save')}}</button>

            </form>
        </div>
    </div>

</div>


@endsection
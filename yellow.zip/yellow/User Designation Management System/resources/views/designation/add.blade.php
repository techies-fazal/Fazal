@extends('layouts.master')

@section('content')

<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">{{__('Designation Management')}}</h1>
        <a href="{{route('designation.index')}}" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-arrow-left fa-sm text-white-50"></i> {{__('Back')}}</a>
    </div>

    {{-- Alert Messages --}}
    @include('common.alert')
    <div id="flash-message-designation"></div>
    <div class="alert alert-danger print-error-msg" style="display:none">
                <ul></ul>
            </div>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">{{__('Add New Designation')}}</h6>
        </div>
        <div class="card-body">
          

        <form id="designation_form"  method="POST">
        @csrf
            <input type="hidden" id="url_id" name="id" value="{{route('form.store')}}" />
            <input type="hidden" id="back_url" name="id" value="{{route('designation.index')}}" />
                <div class="form-group row">
                    {{-- Designation Title --}}
                    <div class="col-sm-6 mb-3 mb-sm-0">
                    <div class="form-group">
                        {{ Form::label('designation_title', __('Designation Title'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                        <input type="text" class="form-control form-control-user @error('designation_title') is-invalid @enderror" id="designation_title" placeholder="Enter Designation Name" name="designation_title" value="{{ old('designation_title') }}">
                        <span class="text-danger" id="error_title"></span>
                    </div>
                    </div>
                    {{-- Designation Name --}}
                    <div class="col-sm-6 mb-3 mb-sm-0">
                         <div class="form-group">
                        {{ Form::label('designation_name', __('Designation Name'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                        <input type="text" class="form-control form-control-user @error('designation_name') is-invalid @enderror" id="designation_name" placeholder="Enter Designation Name" name="designation_name" value="{{ old('designation_name') }}">
                        <span class="text-danger" id="error_name"></span>
                    </div> </div>
                    {{-- Designation Status --}}
                    <div class="col-sm-6 mb-3 mb-sm-0">
                         <div class="form-group">
                        {{ Form::label('designation_status', __('Designation Status'), ['class' => 'col-form-label']) }}<span class="text-danger pl-1">*</span>
                        <select id="designation_status" name="designation_status" class="form-control form-control-user @error('designation_status') is-invalid @enderror">
                            <option value="" selected>{{__('Select Designation Status')}}</option>
                            <option value="0">{{__('Active')}}</option>
                            <option value="1">{{__('Inactive')}}</option>
                        </select>
                        <span class="text-danger" id="error_status"></span>
                        </div>
                    </div>
                    
                </div>
               
                <button type="submit" class="btn btn-success btn-user btn-block"id="submit_designation" value="create">{{__('Submit')}}</button>
                </form>
                {{-- Save Button --}}
              
        </div>
    </div>

</div>


@endsection


 
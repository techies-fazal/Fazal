@extends('layouts.master')

@section('content')
<link href="//cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css" rel="stylesheet">
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">{{__('Designation Management')}}</h1>
        @if (\Auth::user()->is_admin == 1)
            <a href="{{route('designation.create')}}" class="btn btn-sm btn-primary" ><i class="fas fa-plus"></i> {{__('Add New')}}</a>
        @endif
    </div>

    {{-- Alert Messages --}}
    @include('common.alert')
   
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">{{__('Designation Details')}}</h6>
            
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th scope="col">{{__('SL No')}}</th> 
                            <th scope="col">{{__('Designation Title')}}</th>
                            <th scope="col">{{__('Designation Name')}}</th>
                            <th scope="col">{{__('Designation Status')}}</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                    @if ($designations->count())
                        <?php $sl_no=1;  ?>
                       @foreach ($designations as $designation)
                            <tr>
                                <td>{{ $sl_no }}</td>
                                <td>{{$designation->designation_title ?? ''}}</td>
                                <td>{{$designation->designation_name ?? ''}}</td>
                                @if($designation->designation_status == 0)
                                    <td>{{__('Active')}}</td>
                                @else
                                    <td>{{__('InActive')}}</td>
                                @endif
                               
                            </tr>
                            <?php $sl_no++;  ?>
                       @endforeach
                       @else
                        <tr>
                            <td colspan="8">
                            <h3 class="text-center">{{__('No Data Availble')}}</h3>
                            </td>
                        </tr>
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>


@endsection
 

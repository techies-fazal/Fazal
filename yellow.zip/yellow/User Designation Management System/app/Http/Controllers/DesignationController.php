<?php

namespace App\Http\Controllers;
use App\Models\Designation;
use DB;
use Validator;
use Illuminate\Http\Request;

class DesignationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $designations = Designation::get();
        return view('designation.list', compact('designations'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('designation.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
 

    public function designationStore(Request $request)
    {
         


        $validator = Validator::make($request->all(), [
            'designation_title' => 'required',
            'designation_name' => 'required',
            'designation_status' => 'required'
        ]);
  
        if ($validator->fails()) {
            return response()->json([
                        'error' => "Internal Server Error",
                    ]);
        }
        else{

      


            $designation = new Designation;

            $designation->designation_title = $request->designation_title;
            $designation->designation_name = $request->designation_name;
            $designation->designation_status = $request->designation_status;


            $result = $designation->save();

            if($result) {
                // return response()->json(['success'=>'Post saved successfully.']);
                return response()->json([
                    'success' => "Designation Inserted Successfully",
                    "code"    => 200
                ]);
            } else  {
                return response()->json([
                    'message' => "Internal Server Error",
                    "code"    => 500
                ]);
            }
        }
    }

    public function storeE(Request $request)
    {
         
        $validatedData = $request->validate([
          'designation_title' => 'required',
          'designation_name' => 'required',
          'designation_status' => 'required'
        ]);

        if($validatedData)
        {
            $save = new Designation;
            $save->designation_title = $request->designation_title;
            $save->designation_name = $request->designation_name;
            $save->designation_status = $request->designation_status;

        $save->save(); 

        return redirect('designation')->with('success', 'Form Data Has Been validated and Designation Details Stored Successfully');
        }
        

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $designations =  Designation::whereId($id)->first();

        if(!$designations){
            return back()->with('error', 'Designation Details Not Found');
        }

        return view('designation.edit', compact('designations'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     // Update record
    public function updateUser(Request $request){

        $name = $request->input('name');
        $email = $request->input('email');
        $editid = $request->input('editid');

        if($name !='' && $email != ''){
        $data = array('name'=>$name,"email"=>$email);

        // Call updateData() method of Page Model
        Designation::updateData($editid, $data);
        echo 'Update successfully.';
        }else{
        echo 'Fill all fields.';
        }

        exit; 
    }

    public function update($id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}

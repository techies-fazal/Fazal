<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Designation;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Auth;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users= User::orderBy('name')->where('is_admin', '!=', Auth::user()->is_admin)->get(); 
        $desig = Designation::where('designation_status', '==', 0)->get();

        return view('users.list', compact('users', 'desig'));
    }
    
    public function get_filter()
    {
      
        $users = User::get('id');
        $campaigns = Campaign::orderBy('id', 'desc')
        ->where('designation','=', $users->designation)
        ->where('status','=',Auth::user()->id)
        ->paginate(10);

        return View::make('campaigns.ajaxShow')->with('campaigns', $campaigns);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        $designations = Designation::where('designation_status', '==', 0)->get();
        return view('users.add', compact('designations'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */


     public function user_store(Request $request)
     {
           
         $user = new User;
 
         $user->name = $request->name;
         $user->email = $request->email;
         $user->contact_no = $request->contact_no;
         $user->alt_contact = $request->alt_contact;
         $user->address = $request->address;
         $user->designation = $request->designation;
         $user->status = $request->status;
         
         $result = $user->save();

         if($result) {
             return response()->json([
                 'success' => "User Inserted Successfully",
                 "code"    => 200
             ]);
         } else  {
             return response()->json([
                 'message' => "Internal Server Error",
                 "code"    => 500
             ]);
         }
     }

     




    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user =  User::whereId($id)->first();
        $designations = Designation::where('designation_status', '==', 0)->get();

        if(!$user){
            return back()->with('error', 'User Not Found');
        }

        return view('users.edit', compact('user', 'designations'));
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    

     public function user_update(Request $request, $id)
    {
      
        $result = User::where('id', $id)->update([
            'name'          => $request->name,
            'email'         => $request->email,
            'contact_no'    => $request->contact_no,
            'alt_contact'   => $request->alt_contact,
            'address'       => $request->address,
            'designation'   => $request->designation,
            'status'        => $request->status
        ]);
        
        if($result) {
            return response()->json([
                'success' => "User Updated Successfully!",
                "code"    => 200,
            ]);
        } else  {
            return response()->json([
                'message' => "Internal Server Error",
                "code"    => 500
            ]);
        }
    }


   



    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function user_delete(Request $request, $id)
    {
        $result = User::where('id', $id)->delete();

        if($result) {
            return response()->json([
                'success' => "User Deleted Successfully!",
                "code"    => 200,
            ]);
        } else  {
            return response()->json([
                'message' => "Internal Server Error",
                "code"    => 500
            ]);
        }
    }

     
}

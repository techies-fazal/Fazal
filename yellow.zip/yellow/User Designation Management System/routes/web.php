<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DesignationController;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::resource('users', App\Http\Controllers\UserController::class);
Route::resource('designation', App\Http\Controllers\DesignationController::class);

Route::post('/user_store', [UserController::class, 'user_store'])->name('users.store');
Route::post('/update/{id}', [UserController::class, 'user_update'])->name('users.update');
Route::get('/delete/{id}',  [UserController::class, 'user_delete'])->name('users.delete');

Route::post('/get_filter',  [UserController::class, 'get_filter'])->name('users.get_filter');

 Route::post('/designationStore', [DesignationController::class, 'designationStore'])->name('form.store');
// Route::post('/store', 'DesignationController@store')->name('form.store');



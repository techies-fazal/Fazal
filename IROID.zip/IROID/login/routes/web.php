<?php
  
use Illuminate\Support\Facades\Route;
  
use App\Http\Controllers\Auth\AuthController;
  
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
  
Route::get('login', [AuthController::class, 'index'])->name('login');
Route::post('post-login', [AuthController::class, 'postLogin'])->name('login.post'); 
Route::get('registration', [AuthController::class, 'registration'])->name('register');
Route::post('post-registration', [AuthController::class, 'postRegistration'])->name('register.post'); 
Route::get('dashboard', [AuthController::class, 'dashboard'])->name('dash');; 
Route::get('logout', [AuthController::class, 'logout'])->name('logout');

Route::post('add_company', [AuthController::class, 'add_company'])->name('add.company'); 
Route::post('add_employee', [AuthController::class, 'add_employee'])->name('add.employee');

 




Route::get('employee', [AuthController::class, 'pagination'])->name('employee_detail');
// Update
Route::get('employee_edit/{id}', [AuthController::class, 'employee_edit'])->name('edit.employee');

Route::post('employee_update/{id}', [AuthController::class, 'employee_update'])->name('update.employee');

## Delete
Route::get('/employee_delete/{id}', [AuthController::class, 'employee_destroy'])->name('delete.employee');
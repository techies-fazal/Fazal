<?php $__env->startSection('content'); ?>
<style>
    .pb-20{
        padding-bottom: 10px;
    }
</style>
<link rel="stylesheet" href="/assets/css/custom.css" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<div class="container">
   <div class="row justify-content-center pad-bot ">
      <div class="col-md-8">
         <?php if(session('success')): ?>
         <div class="alert alert-success" id="alert" role="alert" align="center">
            <?php echo e(session('success')); ?>

         </div>
         <?php endif; ?>
      </div>
   </div>
   <div class="row">
      <div class="col-md-12">
         <div class="card">
            <div class="card-header">
                <h3 align="center">Edit Employees</h3>
                <div class="card-body" id="employee">
                    <form action="<?php echo e(route('update.employee',[$employees->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label for="first_name" class="col-md-4 col-form-label text-md-left">First Name</label>
                        <div class="col-md-6 pb-20">
                            <input type="text" id="first_name" class="form-control" value="<?php echo e($employees->first_name); ?>" name="first_name" required autofocus>
                            <?php if($errors->has('first_name')): ?>
                            <span class="text-danger"><?php echo e($errors->first('first_name')); ?></span>
                            <?php endif; ?>
                        </div>
                        <label for="last_name" class="col-md-4 col-form-label text-md-left">Last name</label>
                        <div class="col-md-6 pb-20">
                            <input type="text" id="last_name" class="form-control" value="<?php echo e($employees->last_name); ?>" name="last_name" required autofocus>
                            <?php if($errors->has('last_name')): ?>
                            <span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
                            <?php endif; ?>
                        </div>
                        <label for="company_id" class="col-md-4 col-form-label text-md-left">Company Name</label>
                        <div class="col-md-6 pb-20">
                            <select  name="company_id" id="company_id" class="form-control">
                                <option selected disabled>Select Company Name</option>
                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($company->id); ?>" <?php if($company->id== $employees->company_id): ?> selected <?php endif; ?> ><?php echo e($company->company_name); ?></option> 
                                  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('company_id')): ?>
                            <span class="text-danger"><?php echo e($errors->first('company_id')); ?></span>
                            <?php endif; ?>
                        </div>
                        <label for="email" class="col-md-4 col-form-label text-md-left">Email</label>
                        <div class="col-md-6 pb-20">
                            <input type="email" id="email" class="form-control" value="<?php echo e($employees->email); ?>" name="email" required autofocus>
                            <?php if($errors->has('email')): ?>
                            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>
                        </div>
                        <label for="phone" class="col-md-4 col-form-label text-md-left">Phone</label>
                        <div class="col-md-6 pb-20">
                            <input type="number" id="phone" class="form-control" value="<?php echo e($employees->phone); ?>" name="phone" required autofocus onkeypress="return isNumberKey(event)">
                            <?php if($errors->has('phone')): ?>
                            <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary bt-wdt">Update</button>
                            <a href="<?php echo e(route('dash')); ?>" class="btn btn-danger">Cancel</a>
                        </div>
                    </div>
                    </form>
                </div>

            </div>
         </div>
      </div>

 
    

            
        </div> 
   </div>
</div>


   
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="//cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/login/resources/views/edit_emp.blade.php ENDPATH**/ ?>
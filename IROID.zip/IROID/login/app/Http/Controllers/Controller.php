<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Company;
use App\Models\Employee;
use Session;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;



    public function add_company(Request $request )
    {  
        
        $validator = \Validator::make(
            $request->all(), [
                               'company_name' => 'required',
                               'company_email' => 'required',
                               'company_logo' => 'mimes:jpeg,png,jpg,svg,pdf,doc,zip|max:2048',
                           ]
        );
        if($validator->fails())
        {
            $messages = $validator->getMessageBag();

            return redirect()->back()->with('error', $messages->first());
        }
        
        if(!empty($request->company_logo))
        {

            $filenameWithExt = $request->file('company_logo')->getClientOriginalName();
            $filename        = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            $extension       = $request->file('company_logo')->getClientOriginalExtension();
            $fileNameToStore = $filename . '_' . time() . '.' . $extension;
            $dir             = storage_path('app/public/');

            // dd($fileNameToStore);
            // $path = $request->file($fileNameToStore)->store('uploads/documentUpload/');

            $path = $request->file('company_logo')->storeAs('app/public', $fileNameToStore);
        }
      
   
        $company              = Company::create([
            'company_name' => $request->company_name,
            'company_email' => $request->company_email,
            'company_logo' => $fileNameToStore,
        ]);
    
        return redirect("dashboard")->withSuccess('Company added successfully');
    }


    public function add_employee(Request $request )
    {  
        $validator = \Validator::make(
            $request->all(), [
                               'first_name' => 'required',
                               'last_name' => 'required',
                               'company_id' => 'required',
                               'email' => 'required',
                               'phone' => 'required',
                               
                           ]
        );
        if($validator->fails())
        {
            $messages = $validator->getMessageBag();

            return redirect()->back()->with('error', $messages->first());
        }


        $company              = Employee::create([
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'company_id' => $request->company_id,
            'email' => $request->email,
            'phone' => $request->phone,
            
             
        ]);

        return redirect("dashboard")->withSuccess('Employee added successfully');

    }

    public function pagination(Request $request)
    {
        
        if ($request->ajax()) {
            $data = Employee::get();
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function($row){
                    $actionBtn = '<a href="javascript:void(0)" class="edit btn btn-success btn-sm">Edit</a> <a href="javascript:void(0)" class="delete btn btn-danger btn-sm">Delete</a>';
                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }

        return view('dashboard');
    }



    public function employee_edit($id)
    {
      
            $employees = Employee::find($id);
            $companies = Company::get();

            return view('edit_emp', compact('employees', 'companies'));
         
    }

     public function employee_update(Request $request,$id)
     {
        $data = $request->except('_method','_token','submit');
        $validator = \Validator::make(
            $request->all(), [
                            'first_name' => 'required',
                            'last_name' => 'required',
                            'company_id' => 'required',
                            'email' => 'required',
                            'phone' => 'required',
                           ]
        );

        if($validator->fails())
        {
            $messages = $validator->getMessageBag();

            return redirect()->back()->with('error', $messages->first());
        }
        $employee = Employee::find($id);
  
        if($employee->update($data)){
  
           Session::flash('message', 'Update successfully!');
           Session::flash('alert-class', 'alert-success');
           return redirect("dashboard")->withSuccess('Product Updated successfully');
        }else{
           Session::flash('message', 'Data not updated!');
           Session::flash('alert-class', 'alert-danger');
        }
  
        return Back()->withSuccess('Data not updated');


     }

     public function employee_destroy($id){
       
        Employee::destroy($id);
  
        Session::flash('message', 'Delete successfully!');
        Session::flash('alert-class', 'alert-success');
        return redirect("dashboard");
     }

    
    
     
 



}

@extends('layout')
@section('content')
<style>
    .pb-20{
        padding-bottom: 10px;
    }
</style>
<link rel="stylesheet" href="/assets/css/custom.css" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<div class="container">
   <div class="row justify-content-center pad-bot ">
      <div class="col-md-8">
         @if (session('success'))
         <div class="alert alert-success" id="alert" role="alert" align="center">
            {{ session('success') }}
         </div>
         @endif
      </div>
   </div>
   <div class="row">
      <div class="col-md-12">
         <div class="card">
            <div class="card-header">
               <button class="btn btn-primary" id="card-body-1">Add Company</button>
               <button class="btn btn-primary" id="card-body-2">Add Employees</button>

                <div class="card-body" id="company" >
                    <form action="{{ route('add.company') }}" method="POST" enctype="multipart/form-data" id="company">
                    @csrf
                    <div class="form-group row">
                        <label for="company_name" class="col-md-4 col-form-label text-md-left">Company Name</label>
                        <div class="col-md-6 pb-20">
                            <input type="text" id="company_name" class="form-control" name="company_name" required autofocus>
                            @if ($errors->has('company_name'))
                            <span class="text-danger">{{ $errors->first('company_name') }}</span>
                            @endif
                        </div>
                        <label for="company_email" class="col-md-4 col-form-label text-md-left">Company Email</label>
                        <div class="col-md-6 pb-20">
                            <input type="email" id="company_email" class="form-control" name="company_email" required autofocus>
                            @if ($errors->has('company_email'))
                            <span class="text-danger">{{ $errors->first('company_email') }}</span>
                            @endif
                        </div>
                        <label for="company_logo" class="col-md-4 col-form-label text-md-left">Company Logo</label>
                        <div class="col-md-6 pb-20">
                            <input type="file" id="company_logo" class="form-control" name="company_logo" required autofocus>
                            @if ($errors->has('company_logo'))
                            <span class="text-danger">{{ $errors->first('company_logo') }}</span>
                            @endif
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary bt-wdt">Add</button>
                        </div>
                    </div>
                    </form>
                </div>

                <div class="card-body" id="employee">
                    <form action="{{ route('add.employee') }}" method="POST">
                    @csrf
                    <div class="form-group row">
                        <label for="first_name" class="col-md-4 col-form-label text-md-left">First Name</label>
                        <div class="col-md-6 pb-20">
                            <input type="text" id="first_name" class="form-control" name="first_name" required autofocus>
                            @if ($errors->has('first_name'))
                            <span class="text-danger">{{ $errors->first('first_name') }}</span>
                            @endif
                        </div>
                        <label for="last_name" class="col-md-4 col-form-label text-md-left">Last name</label>
                        <div class="col-md-6 pb-20">
                            <input type="text" id="last_name" class="form-control" name="last_name" required autofocus>
                            @if ($errors->has('last_name'))
                            <span class="text-danger">{{ $errors->first('last_name') }}</span>
                            @endif
                        </div>
                        <label for="company_id" class="col-md-4 col-form-label text-md-left">Company Name</label> 
                        <div class="col-md-6 pb-20"> 
                            <select name="company_id" id="company_id" class="form-control">
                                <option selected disabled>Select Company Name</option>
                                @foreach($companies as $key => $company)
                                    <option value="{{$key ?? ''}}">{{$company ?? ''}}</option>
                                @endforeach
                            </select>
                            <!-- @if ($companies->count() == 0) -->
                                <button class="btn btn-primary bt-wdt" id="card-body-3">Add Company</button>
                            <!-- @endif    -->
                            @if ($errors->has('company_id'))
                            <span class="text-danger">{{ $errors->first('company_id') }}</span>
                            @endif
                        </div>
                        <label for="email" class="col-md-4 col-form-label text-md-left">Email</label>
                        <div class="col-md-6 pb-20">
                            <input type="email" id="email" class="form-control" name="email" required autofocus>
                            @if ($errors->has('email'))
                            <span class="text-danger">{{ $errors->first('email') }}</span>
                            @endif
                        </div>
                        <label for="phone" class="col-md-4 col-form-label text-md-left">Phone</label>
                        <div class="col-md-6 pb-20">
                            <input type="number" id="phone" class="form-control" name="phone" required autofocus onkeypress="return isNumberKey(event)">
                            @if ($errors->has('phone'))
                            <span class="text-danger">{{ $errors->first('phone') }}</span>
                            @endif
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary bt-wdt">Add</button>
                        </div>
                    </div>
                    </form>
                </div>

            </div>
         </div>
      </div>

 
    <div class="col-md-12" style="padding-top: 50px;">
      <table id="empTable" width='100%' border="1" style='border-collapse: collapse;'>
      <h4 class="text-md-center">Employee Details</h4>
        <thead>
            <tr>
                <th>SL No</th> 
                <th>First name</th>
                <th>Last Name</th>
                <th>Company Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @if ($showEmployeeData->count())
                <?php $sl_no=1;  ?>
                @foreach ($showEmployeeData as $employee)
                    <tr id="clr_tr">
                    <td>{{ $sl_no }}</td>
                    <td>{{$employee->first_name ?? ''}}</td>
                    <td>{{$employee->last_name ?? ''}}</td>
                    <td>{{$employee->company_name->company_name ?? ''}}</td>
                    <td>{{$employee->email ?? ''}}</td>
                    <td>{{$employee->phone ?? ''}}</td>
                    <td>
                        <a href="{{ route('edit.employee',[$employee->id]) }}" class="btn btn-success">Edit</a>
                        <a href="{{ route('delete.employee',[$employee->id]) }}" class="btn btn-danger">Delete</a>
                    </td>
                    </tr>
                    <?php $sl_no++;  ?>
                @endforeach
            </tbody>
            @else
            <tr>
               <td colspan="8" >
                  <h3>No Data Availble</h3>
               </td>
            </tr>
            @endif
    </table>

            <!-- <div class="container" style="padding-top: 50px;">
                <h1>Employee Details</h1>
                <table class="table table-bordered data-table">
                    <thead>
                        <tr>
                            <th>First name</th>
                            <th>Last Name</th>
                            <th>Company Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div> -->


        </div> 
   </div>
</div>


   
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="//cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

  <script>
    $(document).ready(function () {
             


     





            $("#company").hide();
            $("#employee").hide();

            $("#card-body-1").click(function(){
                $("#company").show();
                $("#employee").hide();
            });

            $("#card-body-2").click(function(){
                $("#company").hide();
                $("#employee").show();
            });

            $("#card-body-3").click(function(){
                $("#company").show();
                $("#employee").hide();
            });

// pagination Datatable
            $('#empTable').DataTable({
            });


        // dive hide 
        $('#alert').delay(1000).fadeOut();


        function isNumberKey(evt){
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57))
            {
                return false;
            }
        return true;
    }



        // var table = $('.data-table').DataTable({
        // processing: true,
        // serverSide: true,
        // ajax: "{{ route('employee_detail') }}",


        // columns: [
        //     {data: 'first_name', name: 'first_name'},
        //     {data: 'last_name', name: 'last_name'},
        //     {data: 'company_name', name: 'company_name'},
        //     {data: 'email', name: 'email'},
        //     {data: 'phone', name: 'phone', orderable: false, searchable: false},
        // ]
        // });


  

    });


</script>
@endsection